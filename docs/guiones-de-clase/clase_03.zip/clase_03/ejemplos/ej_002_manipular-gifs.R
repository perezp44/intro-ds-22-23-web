#- https://statisticaloddsandends.wordpress.com/2020/08/06/basic-manipulation-of-gif-frames-with-magick/
#- pkg para manipular imagenes
library(magick) #- install.packages("magick")

#- en esta ruta hay un gif -----------------------------------------------------
img_path <- "https://media4.giphy.com/media/lrf5jEbnpVUek/giphy.gif?cid=ecf05e47ye2fmifliirogo6cmq391fsz8iqzumnmy0g19sxl&rid=giphy.gif&ct=g"
#- img_path <- "./imagenes/Jordan.gif" 

img <- magick::image_read(img_path) #- leemos el gif

img   #- podemos ver el gif

print(img)   #- el gif tiene 62 frames




#- manipulamos el gif y repetimos algun frame ----------------------------------
img[c(1:44, 
    rep(c(rep(44, times = 5), 
    43:30, 
    rep(30, times = 5), 31:43), times = 2))]
#- otros efectos
img[c(15:40, rep(40:47, each = 6))]



#- leemos una imagen, el logo de R ---------------------------------------------
logo <- magick::image_read("https://jeroen.github.io/images/Rlogo.png") %>%
        magick::image_resize("480x266!")
#- logo <- "./imagenes/R-logo.png"

#- insertamos el logo de R en el gif
img[c(25:30)] <- logo
img




#- ponemos dentro del gif a NV -------------------------------------------------
NV <- magick::image_read("./imagenes/NV.jpg")
img[22] <- NV
img[c(15:30, rep(21:23, each = 4))] #- metemos a NV dentro
