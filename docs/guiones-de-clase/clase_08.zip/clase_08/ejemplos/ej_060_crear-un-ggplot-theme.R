#- https://austinwehrwein.com/tutorials/corporatethemes/
#- esta chulo el theme de  theme_ipsum from the hrbrthemes package by Bob Rudis
library(tidyverse) #ggplot2 et al
library(gcookbook) #just for sample plot data
library(RColorBrewer)

corporate_colors <- c('#39916C',
                      '#3B6788',
                      '#D49D54',
                      '#c45a31',
                      '#9f9f9f')
scales::show_col(corporate_colors)
#------------------------------------ define un theme
corp_theme <- function(
    base_family="Roboto",
    base_size =9,
    plot_title_family='Merriweather Black',
    plot_title_size = 20,
    plot_title_color = corporate_colors[1], #maybe use your first corporate color?
    grid_col='#DADADA'){ #use those variables
    aplot <- ggplot2::theme_minimal(base_family=base_family, base_size=base_size) #piggyback on theme_minimal
    aplot <- aplot + theme(panel.grid=element_line(color=grid_col))
    aplot <- aplot + theme(plot.title=element_text(size=plot_title_size,
                                                   family=plot_title_family,
                                                   color=plot_title_color))
    aplot
}


heightweight.5 <- filter(heightweight, ageYear <= 16)

ggplot(heightweight.5,aes(heightIn,ageYear, color = factor(round(ageYear)))) +
    geom_point(alpha=.6) +
    geom_smooth(se=FALSE) +
    scale_color_manual(values=corporate_colors) +
    corp_theme() +
    labs(title='Corporate Chair Coalition ltd.',
         subtitle='Business is booming',
         color='Age',
         x='Height (in)',
         y='Age',
         caption='Data: R Graphics Cookbook')
