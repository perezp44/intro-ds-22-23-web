#- https://github.com/benyamindsmith/mapBliss

library(mapBliss) #- devtools::install_github("benyamindsmith/mapBliss")


plot_hybrid_route(addresses=c("Nashville",
                              "Seattle",
                              "San Diego",
                              "Nashville"),
                  how = c("flight","car","flight"))


plot_hybrid_route(addresses = c("Madrid", "Valencia, Spain", "Pancrudo, Spain"),
                  how = c("car","car"))

plot_city_view("Pancrudo, Spain")




#- https://cran.r-project.org/web/packages/openairmaps/readme/README.html
#- https://bookdown.org/david_carslaw/openair/access-met-data.html
library(openairmaps) #- devtools::install_github("davidcarslaw/openairmaps")
networkMap(source = "europe")


aa <- worldmet::getMeta()  #- install.packages("worldmet")
worldmet::getMeta(lat = 39.483, lon = -0.383, returnMap = TRUE)

worldmet::getMeta(site = "VALENCIA VIVEROS", returnMap = TRUE)
vlc_met <- worldmet::importNOAA(code = "082850-99999", year = 2019)
openair::windRose(vlc_met)


