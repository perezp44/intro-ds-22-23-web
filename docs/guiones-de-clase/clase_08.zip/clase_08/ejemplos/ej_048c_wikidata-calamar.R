# WIKIDATA, hay que conocerla mas!!!!
#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners
#- https://www.wikidata.org/wiki/Wikidata:Main_Page



library(tidyverse)
library(wikifacts) 
#------------- query sobre El juego del Calamar
#- Los datos de Tidy Tuesday tenian los datos hasta 2016, ¿y los de 2017, 2018 y 2019?
#- hagamos una querie a Wikidata: https://query.wikidata.org/


#--- query en SPARQL
#Peliculas en las que han intervenido los actores del juego del calamar
SELECT ?show ?showLabel (GROUP_CONCAT(?castmemberLabel;separator="; ") as ?castlabels)   WHERE {
    wd:Q106582931 wdt:P161 ?castmember.
    ?castmember ^wdt:P161 ?show.
    FILTER ( ?show not in ( wd:Q106582931 ) )
    SERVICE wikibase:label {
        bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en,ko".
        ?castmember rdfs:label ?castmemberLabel .
        ?show rdfs:label ?showLabel .
    }
}
GROUP BY ?show ?showLabel


#- query desde R -------------------------------------------------------------
library(tidyverse)
library(wikifacts) 

query <- 
    'SELECT ?show ?showLabel (GROUP_CONCAT(?castmemberLabel;separator="; ") as ?castlabels)   WHERE {
    wd:Q106582931 wdt:P161 ?castmember.
    ?castmember ^wdt:P161 ?show.
    FILTER ( ?show not in ( wd:Q106582931 ) )
    SERVICE wikibase:label {
        bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en,ko".
        ?castmember rdfs:label ?castmemberLabel .
        ?show rdfs:label ?showLabel .
    }
}
GROUP BY ?show ?showLabel'

#- mando la consulta a wikidata
# df_calamar_wiki <- wiki_query(query)
# rio::export(df_calamar_wiki, "./datos/df_calamar_wiki.csv")

#- recupero los datos obtenidos en la consulta a Wikidata
df_orig <- readr::read_csv("./datos/df_calamar_wiki.csv")
df <- df_orig #- voy a trabajar con df

#- vemos los países con mas Nóbeles en 2021
names(df)
aa <- df %>% count(castlabels) %>% arrange(desc(n))
aa <- df %>% count(showLabel) %>% arrange(desc(n))

aa <- df %>% filter(castlabels == "Lee Byung-hun")


#- Wikidata mola!!!  Wikidata, hay que conocerla más!! -------------------------

#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- video más largito: https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners.webm


#- wikidata: https://www.wikidata.org/wiki/Wikidata:Main_Page
#- wikidata Queries: https://query.wikidata.org/