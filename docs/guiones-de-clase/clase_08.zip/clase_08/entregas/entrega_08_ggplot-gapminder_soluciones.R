#- ENTREGA nº 08
#---- Pon tus datos de identificación ------------------------------------------
#- Apellidos: 
#- Nombre: 
#- e-mail: 
#- NPA: 
# -----------------------------------------------------------------------------.
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
# -----------------------------------------------------------------------------.
#- Solo has de subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, no hay que subir el Rproject, hay que subir solo el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_08_perez_pedro_GG445566.R
# -----------------------------------------------------------------------------.



#- Objetivo: practicar un poco gráficos con ggplot2 


#- PRIMERA TAREA: --------------------------------------------------------------
#- utiliza el data.frame gapminder del paquete gapminder para hacer un gráfico de puntos de la variable "gdpPercap" (en el eje X) frente a la variable "lifeExp". Utiliza sólo los datos del último año (2007)
#- Recuerda que las variables que quieras q se muestren en el gráfico van dentro de aes()
#- has de cargar librerias, "arreglar" los datos y después hacer el gráfico
library(tidyverse)
library(gapminder)
gapminder_2007 <- gapminder %>% filter(year == 2007) #- selecciono observaciones de 2007

#- para el gráfico hay varias opciones, por ejemplo:
p1 <- ggplot(gapminder_2007, aes(x = gdpPercap, y = lifeExp)) + geom_point()
p1 <- ggplot(gapminder_2007) +  geom_point(aes(x = gdpPercap, y = lifeExp))
p1 <- ggplot() + geom_point(data = gapminder_2007, aes(x = gdpPercap, y = lifeExp))

p1 <- ggplot(gapminder_2007, aes(x = gdpPercap, y = lifeExp)) + geom_point()
p1

#- SEGUNDA TAREA: --------------------------------------------------------------
# haz que el color de los puntos sea diferente en función del continente
p2 <- ggplot(gapminder_2007, aes(x = gdpPercap, y = lifeExp, color = continent)) + geom_point()
p2


#- TERCERA TAREA: --------------------------------------------------------------
#- En el mismo gráfico de antes, hay que marcar, hay que hacer que resalten, que se vean mejor los siguientes países: Spain, Poland and Italy
#- Pista: Igual puedes crear un df con solo las observaciones de esos 3 países y ponerlo encima del gráfico con un color que se vea bien tipo "orange" o con un tamaño grande (7 ya es muy grande) del punto, o las 2 cosas a la vez casi mejor.


gapminder_3 <- gapminder %>% 
               filter(year == 2007)  %>% 
               filter(country %in% c("Spain", "Italy", "Poland"))
p3 <- p1 + geom_point(data = gapminder_3, color = "orange", size = 3,shape=21, stroke = 1.2)

p3
#- CUARTA TAREA: ---------------------------------------------------------------
# Partiendo del gráfico de la TAREA 2; es decir, sin que se marquen Spain, Italy y Poland, ahora vamos a añadir (vamos a representar) una cuarta variable en el gráfico. Añade al gráfico la variable "pob" (poblacion), para ello asóciala/mapeala a la aesthetic "size"

p4 <- p + geom_point(aes(color = continent, size = pop))
p4 <- ggplot(gapminder_2007, aes(x = gdpPercap, y = lifeExp)) + 
    geom_point(aes(color = continent, size = pop))
p4

#- QUINTA TAREA: ---------------------------------------------------------------
#- hay que intentar dejar el gráfico más bonito. Igual tienes que jugar con el parámetro/aesthetic "alpha" que regula la transparencia del color. 

p5 <- ggplot(gapminder_2007, aes(x=gdpPercap, y = lifeExp, size = pop, fill = continent)) +
  geom_point(alpha = 0.5, shape = 21, color = "black", stroke = 5) +
  scale_size(range = c(.1, 24), name = "Population (M)") 
  
p5

library(viridis)
p_galina <- gapminder_2007 %>% 
ggplot(aes(x = gdpPercap, y = lifeExp, size = pop, fill = continent)) +
  geom_point(alpha = 0.5, shape = 21, color = "black") +
  scale_size(range = c(.1, 24), name = "Population (M)") +
  scale_fill_viridis(discrete = TRUE, option="A") +
  #theme_ipsum() +
  #theme(legend.position="bottom") +
  ylab("Life Expectancy") +
  xlab("Gdp per Capita") +
  theme(legend.position = "none")

p_galina


#- SEXTA TAREA: ----------------------------------------------------------------
#- haz un "small multiple" con un gráfico por año

p6 <- ggplot(gapminder) +  #- tengo q usar los datos de todos los años, no solo los de 2007
  geom_point(aes(x = gdpPercap, y = lifeExp, colour = continent)) +
  facet_wrap(vars(year))
p6

#- SEPTIMA TAREA: --------------------------------------------------------------
#- Partiendo del gráfico de la tarea anterior (p6)
#- vamos a mejorar un poco el gráfico. Para ello:
#- Pon título, subtítulo, caption, eje X, eje Y y título de la leyenda

p7 <- p6 + labs(title = "Gráfico 1: PIB percápita frente a Esperanza de vida",
              subtitle = "(por año)",
              caption = "Datos provenientes del paquete gapminder",
              x = "PIB percápita",
              y = "Esperanza de vida",
              color = "Continente")
p7





#- OCTAVA TAREA: ---------------------------------------------------------------
# Marca/señala en el gráfico anterior con una ANOTACIÓN el país (de cada continente) con una mayor esperanza de vida en 2007

gapminder_2007_max <- gapminder_2007 %>% 
  group_by(continent) %>% 
  slice_max(lifeExp, n = 1) 

p8 <- p7 + 
  geom_text(data = gapminder_2007_max, 
            aes(label = country,  x = gdpPercap, y = lifeExp), 
            color = "black", size = 3)
  
p8

#- solución de Lena
gap <- gapminder
paises <- gap %>% filter(year == 2007) %>% group_by(continent)%>% filter(gdpPercap == max(gdpPercap, na.rm = TRUE))
paises_2 <- paises %>% pull(country)

gap_p <- gap %>% filter(country == "Australia"| country =="Gabon"|country =="Kuwait"|country =="Norway"|country =="United States")

p8 <- p7 + geom_text(data = gap_p, aes(label = country), color = "black", size = 2)

p8  #- pero su solución no funciona en MI script(xq)

p8 <- p7 + geom_text(data = gap_p, aes(label = country, x = gdpPercap, y = lifeExp, colour = continent), color = "black", size = 2)

#- NOVENA TAREA: ---------------------------------------------------------------
# partiendo del gráfico de la tarea anterior (p7)
#- Haz el gráfico interactivo. Para ello usa plotly::ggplotly()
plotly::ggplotly(p7)



#- DECIMA TAREA: ---------------------------------------------------------------
#- Es opcional, sólo si te apetece, tienes tiempo y te sale un gráfico con datos de gapminder que vuela o que habla o que es chulo pónmelo aquí please. Igual podéis hacer un gganimate (!!)



#- http://euclid.psych.yorku.ca/www/psy6135/tutorials/gapminder.html




#- GRAFICOS --------------------------------------------------------------------
#- Luis Pérez (pedazo gráfico!!!) ----------------------------------------------
#- http://euclid.psych.yorku.ca/www/psy6135/tutorials/gapminder.html
library(tidyverse)
library(gapminder)
library(plotly)
g <- crosstalk::SharedData$new(gapminder, ~continent)
#- no hace falta crosstalk
g <- gapminder::gapminder %>% group_by(continent)

#- frame = year (es la aesthetic importante para la transicion)
gg <- ggplot(g, aes(gdpPercap, lifeExp, color = continent, frame = year)) +
  geom_point(aes(size = pop, ids = country)) +
  scale_x_log10() +
  NULL

ggplotly(gg) %>% 
  highlight("plotly_hover")
