library(tidyverse)
p <- ggplot(mtcars, aes(factor(cyl), fill = factor(vs)))
p + geom_bar() 
p + geom_bar(position = "fill")
p + geom_bar(position = "dodge")
p + geom_bar(position = position_dodge2(preserve = "single"))
str(mtcars)


cc <- factor(mtcars$cyl)

typeof(cc)
class(cc)

cc[2] <- 9
cc
aa <- mtcars %>% mutate(cyl.f = as.factor(cyl))


