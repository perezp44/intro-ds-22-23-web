#- poniendo "tiles" en nuestros mapas con el pkg maptiles
#- https://github.com/riatelab/maptiles/
library(sf)
library(maptiles)
# import shapes de Spain
nc_raw <- pjpv.curso.R.2022::LAU2_prov_2020_canarias

#- import shapes de barrios de Valencia

nc_raw <- rio::import("/home/pjpv/Escritorio/mys_COSAS/my_datos_2021/datos/geo_datos_mios/distritos_valencia_geo.rds")
nc_raw <- sf::st_as_sf(nc_raw) #- la convertimos en sf

#--------------------------------
nc <- nc_raw
# Project to EPSG:3857
#- Original tiles use a projection known as “Web Mercator”, “WGS84 / Pseudo Mercator”, “Google Mercator”, “EPSG:3857” or “EPSG:900913”. In most cases get_tiles() uses the projection of its x argument to reproject the tiles. If you wish to avoid any deformation induced by the reprojection process, use “EPSG:3857” for x projection.
nc <- st_transform(nc_raw, "EPSG:3857")
# dowload tiles and compose raster (SpatRaster)
nc_osm <- get_tiles(nc, crop = TRUE)
plot_tiles(nc_osm)


#- PROVIDERS -------------------------------------------------------------------
# "OpenStreetMap.MapnikBW", "OpenStreetMap", "OpenStreetMap.DE", "OpenStreetMap.France", "OpenStreetMap.HOT", 
# "Stamen.Toner", "Stamen.TonerBackground", "Stamen.TonerHybrid", "Stamen.TonerLines", "Stamen.TonerLabels", 
# "Stamen.TonerLite", "Stamen.Watercolor", "Stamen.Terrain", "Stamen.TerrainBackground", "Stamen.TerrainLabels",
# "Esri.WorldStreetMap", "Esri.DeLorme", "Esri.WorldTopoMap", "Esri.WorldImagery", "Esri.WorldTerrain", 
# "Esri.WorldShadedRelief", "Esri.OceanBasemap", "Esri.NatGeoWorldMap", "Esri.WorldGrayCanvas",
# "CartoDB.Positron", "CartoDB.PositronNoLabels", "CartoDB.PositronOnlyLabels", "CartoDB.DarkMatter", 
# "CartoDB.DarkMatterNoLabels", "CartoDB.DarkMatterOnlyLabels", "CartoDB.Voyager",
# "CartoDB.VoyagerNoLabels", "CartoDB.VoyagerOnlyLabels",
# "Thunderforest.OpenCycleMap", "Thunderforest.Transport", "Thunderforest.TransportDark", 
# "Thunderforest.SpinalMap", "Thunderforest.Landscape", "Thunderforest.Outdoors", "Thunderforest.Pioneer",
# "Thunderforest.MobileAtlas", "Thunderforest.Neighbourhood",
# "OpenTopoMap",
# "HikeBike", 
# "Wikimedia

nc_osm <- get_tiles(nc, provider = "CartoDB.Positron", crop = TRUE)
nc_osm <- get_tiles(nc, provider = "Stamen.Watercolor")

# display map-tile
plot_tiles(nc_osm)
# add Norh Carolina counties
plot(st_geometry(nc), col = NA, add = TRUE)
# add credit
mtext(text = get_credit("OpenStreetMap"), 
      side = 1, line = -1, adj = 1, cex = .9, 
      font = 3)


#- ggspatial::tb se pueden añadir tiles  ---------------------------------------
#- ggspatial usa OSM
#- en realidad con muchos mas
library(ggplot2)
library(ggspatial)

ggplot() +
  # loads background map tiles from a tile source
  annotation_map_tile(zoomin = -1) +
    # annotation_spatial() layers don't train the scales, so data stays central
  annotation_spatial(nc, size = 2, col = "red") +
  # annotation_spatial(longlake_roadsdf, size = 1.6, col = "white") +
  # raster layers train scales and get projected automatically
  # layer_spatial(nc, aes(colour = stat(band1))) +
  # make no data values transparent
  scale_fill_viridis_c(na.value = NA) +
    # layer_spatial trains the scales
  layer_spatial(nc, aes(fill = pob_2020)) 
names(nc_raw)



#- https://github.com/statsmaths/ggmaptile
remotes::install_github("statsmaths/ggmaptile")

library(ggplot2)
library(ggmaptile)
library(dplyr)
names(nc_raw)
nc_raw %>%
  ggplot(aes(x = X1, y = Y1)) +
  stat_maptiles() +
  geom_point(aes(x = X1, y = Y1))
