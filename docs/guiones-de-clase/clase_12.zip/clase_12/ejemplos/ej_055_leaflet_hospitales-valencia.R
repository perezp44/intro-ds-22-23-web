#- hospitales de valencia
#- https://aghaynes.wordpress.com/2018/06/11/merging-spatial-buffers-in-r/
#- en el Cloud primero haz restart
#- se pueden poner imagenes, tablas o graficos en pop-up: https://github.com/r-spatial/leafpop

library(osmdata)
library(rgdal)
library(maptools)
library(rgeos)

q <- opq(bbox = "Valencia", timeout = 600)
q1 <- add_osm_feature(q, key = 'building', value = "hospital")
x <- osmdata_sp(q1)

library(leaflet)

spChFIDs(x$osm_polygons) <- 1:nrow(x$osm_polygons@data)
cent <- gCentroid(x$osm_polygons, byid = TRUE)
leaflet(cent) %>% addTiles() %>% addCircles()

buff <- gBuffer(cent, byid = TRUE, width = 0.0015)
leaflet(cent) %>% addTiles() %>% addPolygons(data = buff, col = "red") %>% addCircles()


buff <- SpatialPolygonsDataFrame(buff, data.frame(row.names = names(buff), n = 1:length(buff)))
gt <- gIntersects(buff, byid = TRUE, returnDense = FALSE)
ut <- unique(gt)
nth <- 1:length(ut)
buff$n <- 1:nrow(buff)
buff$nth <- NA
for(i in 1:length(ut)){
  x <- ut[[i]]
  buff$nth[x] <- i
}
buffdis <- gUnaryUnion(buff, buff$nth)


leaflet(cent) %>% addTiles() %>% addPolygons(data = buffdis, col = "red") %>% addCircles()
