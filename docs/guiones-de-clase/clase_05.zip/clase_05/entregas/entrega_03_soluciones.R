#- ENTREGA nº 03 (para hacer en casa)
#- Deadline para la entrega: Jueves a las 23:59
#---- Pon tus datos de identificación ----------------------------
#- Apellidos:
#- Nombre:
#- e-mail:
#- NPA:
#-------------------------------------------------------------------------------
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
#-------------------------------------------------------------------------------
#- Solo tendrás que subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, NO hay que subir el Rproject, hay que SUBIR SOLO el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_03_perez_pedro_GG445566.R
#-------------------------------------------------------------------------------


#- TAREA 01:
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la siguiente ruta "./pruebas/pob_mun_1996_2020.rda"
my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
my_destination <- here::here("pruebas", "pob_mun_1996_2020.rda")

download.file(url = my_url,  destfile = my_destination)        #- con R-base
curl::curl_download(url = my_url,  destfile = my_destination)  #- con el pkg curl mejor


#- TAREA 02:
#- Como vamos a trabajar con los datos que acabas de descargar,
#- ahora tienes que cargar estos en memoria de R, en el Global Environment de R.
#- Por favor, la tabla de datos o data.frame se ha de llamar "df".
#- Os pongo el principio de la instrucción que tenéis que escribir:

df <- rio::import(my_destination) #- ya hemos descargado el fichero, lo importamos del PC, no del url

#- TAREA 03:
#- Los datos que has descargado y cargado en  R tienen 13 columnas (variables) y 194.720 filas o registros
#- son datos de población municipal en España
#- Nos vamos a quedar solo con las observaciones de 2 pueblos de Teruel: Pancrudo y Albarracín
#- y restringo la muestra de años a 2010-2020
#- y como hay muchas columnas me quedo solo con: year, ine_muni.n y pob_total
#- Esto lo hacemos con las siguiente lineas de código:
#- (Recuerda que para poder usar %>%, filter() y select() has de cargar el tidyverse)
#- esta tercera tarea la hago yo 🎉 !!

library(tidyverse)
df_long <- df %>% filter(ine_muni.n %in% c("Pancrudo", "Albarracín")) %>%
           select(year, ine_muni.n, pob_total) %>%
           filter(year >= 2015)


#- TAREA 04:
#- Como ves, df_long, ahora es mas manejable, tiene sólo 3 columnas y 22 filas (11 para cada pueblo)
#- df_long, ¿está en formato tidy? Sí, está en formato tidy-long, perfecto para los ordenadores,
#- pero nuestro cliente/profesor quiere verlo mejor, quiere que haya una columna con los datos de Pancrudo y otra para Albarracín
#- Él no lo sabe, pero quiere pasar los datos de long a formato ancho o wide.
#- Please, pasa los datos de la columna "pob_total" a formato ancho para que haya una columna para cada pueblo

df_wide <- df_long %>%
           pivot_wider(values_from = pob_total, names_from = ine_muni.n)



#- TAREA 05: haz una tabla o cuadro para visionar los datos. Hazla con el paquete "DT". Hay ejemplos en las slides_05
DT::datatable(df_wide)


#- TAREA 06:
#- Tenemos que mandarle los datos en formato ancho a nuestro cliente, ademas quiere los datos en formato .xlsx
#- Por favor, exporta esos datos (df_wide) a formato .xlsx. Guarda los datos en "./pruebas/df_wide.xlsx"
ruta_wide <- here::here("pruebas", "df_wide.xlsx")
rio::export(df_wide, ruta_wide)


#- TAREA 07:
#- Imagina que han pasado varios días y quieres volver a trabajar con los datos del fichero que mandaste a tu cliente
#- Para simular que han pasado varios dias, vamos a borrar todos los objetos del Gobal Env.
rm(list = ls())
#- Una vez que hemos borrado todos los objetos del Global Env.
#- Por favor, importa al Global env. los datos del fichero que creamos para nuestro cliente
ruta_wide <- here::here("pruebas", "df_wide.xlsx")
df_wide <- rio::import(ruta_wide)


#- TAREA 08:
#- Bien ya hemos importado los datos del fichero "df_wide.xlsx" pero como vamos a trabajar con esos datos
#- Por favor, transforma los datos de df_wide a formato LONG

df_long <- df_wide %>%
          pivot_longer(cols = 2:3, names_to = "pueblos", values_to = "poblacion")


#- TAREA 09:
#- Utiliza los datos en formato LONG para volver a pasarlos a formato ANCHO, pero ...
#- PERO esta vez quiero ver, en lugar de una columna para cada pueblo, ahora quiero ver una columna para cada año; una columna para cada valor de la variable "year"

df_wide_2 <- df_long %>%
           pivot_wider(values_from = poblacion, names_from = year)


#- TAREA 10:
#- Supongo que te lo imaginas, vamos a volver a pasar a formato LONG, Sí.
# Por favor, pasa los datos de df_wide_2 aformato LONG

df_long_2 <- df_wide_2 %>%
          pivot_longer(cols = 2:7, names_to = "year")


#- TAREA 11:  esta tarea es OPCIONAL (no es obligatoria)
#- Se trata de que compares tu pueblo con mi pueblo (Pancrudo)
#- Para ello tienes que usar y modificar el código de la TAREA 03 de este script
my_destination <- here::here("pruebas", "pob_mun_1996_2020.rda")

df <- rio::import(my_destination)
tu_pueblo <- "Aliaga"

library(tidyverse)

df_wide_3 <- df %>% filter(ine_muni.n %in% c("Pancrudo", tu_pueblo)) %>%
  select(year, ine_muni.n, pob_total) %>%
  filter(year >= 2015) %>%
  pivot_wider(values_from = pob_total, names_from = ine_muni.n) %>%
  dplyr::relocate(Pancrudo, .after = last_col()) %>%
  mutate(percent_pancrudo_s_tu_pueblo = .[[3]]/.[[2]]) %>%
  mutate(percent_pancrudo_s_tu_pueblo = round(percent_pancrudo_s_tu_pueblo, digits = 2))


DT::datatable(df_long_3)


#- ULTIMA TAREA 12: (tb opcional)
#- borra (usando código) todos los archivos que haya en la carpeta "./datos/pruebas/"
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)
fs::file_delete(lista_de_archivos)

my_carpeta <- "./datos/pruebas"   #- con R-base (por si no tenéis instalado el paquete "fs")
lista_de_archivos <- list.files(my_carpeta, full.names = TRUE)
file.remove(lista_de_archivos)

