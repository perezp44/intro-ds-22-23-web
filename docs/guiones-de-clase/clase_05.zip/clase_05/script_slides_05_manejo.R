#- script para seguir las slides_05 sobre manejo de datos

library(tidyverse)
library(gapminder)


#- slide nº 22 -----------------------------------------------------------------
gapminder <- gapminder::gapminder  #- cargamos los datos

#- Observaciones de España (country == "Spain")
aa <- gapminder %>% filter(country == "Spain") 

#- filas con valores de "lifeExp" < 29
aa <- gapminder %>% filter(lifeExp < 29) 

#- filas con valores de "lifeExp" entre [29, 32]
aa <- gapminder %>% filter(lifeExp >=  29 , lifeExp <= 32)   
aa <- gapminder %>% filter(lifeExp >=  29 &  lifeExp <= 32)  
aa <- gapminder %>% filter(between(lifeExp, 29, 32))   

#- observaciones de países de África con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent == "Africa") 

#- observaciones de países de África o Asia con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )  
aa <- gapminder %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


#- slide nº 23 -----------------------------------------------------------------

#- slice() tb permite seleccionar filas, pero por posicion
#- selecciona las observaciones de la décima a la quinceava
aa <- gapminder %>% slice(c(10:15)) 

#- selecciona las observaciones de la 12 a 14 Y de la 44 a 46, Y las 4 últimas
aa <- gapminder %>% 
  slice( c(12:14, 44:46, n()-4:n()) ) #- AQUI hay un error, tenéis que arreglarlo. 

#- Pista: igual os ayuda crear una columna con el índice de rows y repetir el cálculo
aa <- gapminder %>% mutate(index = 1:n())
aa <- gapminder %>% slice( c(12:14, 44:46, n()-4:n()) )

#- slide nº 24 -----------------------------------------------------------------
#- 1.C Variantes de slice()

#- selecciona las 3 filas con mayor valor de lifeExp
aa <- gapminder %>% slice_max(lifeExp, n = 3)

#- selecciona las 4 filas con MENOR valor de pop
aa <- gapminder %>% slice_min(pop, n = 4)

#- observaciones en el primer decil en cuanto a esperanza de vida, 10% con menor esperanza de vida
aa <- gapminder %>% slice_min(lifeExp, prop = 0.1)

#- 1% de observaciones con mayor población. Imagino que estarán China e India
aa <- gapminder %>% slice_max(pop, prop = 0.01)

#- A veces se necesita obtener una muestra aleatoria de los datos: por ejemplo con slice_sample():
#- selecciona (aleatoriamente) 100 filas de los datos
aa <- gapminder %>% slice_sample(n = 100)

#- selecciona (aleatoriamente) un 5% de los datos
aa <- gapminder %>% slice_sample(prop = 0.05)



#- slide nº 25 -----------------------------------------------------------------
#- arrange(): permite reordenar las filas de un df
#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp 
aa <- gapminder %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(desc(lifeExp))  

#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp. 
#- Si hay empates se resuelve con la variable "pop"
aa <- gapminder %>% arrange(lifeExp, pop) 



#- slide nº 26 -----------------------------------------------------------------
#- rename(): permite cambiar los nombres de las variables
aa <- gapminder

aa %>% rename_with(toupper)

rename_with(aa, toupper, starts_with("Life") | contains("countr"))

rename_with(aa, ~ str_replace(.x, "e", "Ö"))  #- (!!!!)



#- slide nº 27 -----------------------------------------------------------------
#- select() se utiliza para seleccionar variables

#- por nombre--
aa <- gapminder %>% select(year, lifeExp) 

#- por posición--
aa <- gapminder %>% select(1:3, 5)

#- eliminar variables --
aa <- gapminder %>% select(-year)

aa <- gapminder %>% select(-c(year, lifeExp))

#- eliminar variables por posicion
aa <- gapminder %>% select(-c(1:3, 5))


#- slide nº 28 -----------------------------------------------------------------
#- select() junto con where()
aa <- gapminder %>% select(is.numeric)        #- funciona, pero ...

aa <- gapminder %>% select(where(is.numeric)) #- es "preferible" esta segunda expresión

aa <- gapminder %>% select(!where(is.numeric)) #- seleccionamos las v. no-numericas



#- slide nº 29 -----------------------------------------------------------------
#- reordenar las v. del df

#- dejamos en aa solamente a las columnas "year" y "pop"; ADEMÁS, ahora, "pop" irá antes que "year"
aa <- gapminder %>% select(pop, year)

#- dejamos en aa solamente a las columnas "year" y "pop" y les cambiamos el nombre
aa <- gapminder %>% select(poblacion = pop, año = year)

#- everything() es util
#- "gdpPercap" que es la última columna pasa a ser la primera
aa <- gapminder %>% select(gdpPercap, everything())

#- relocate() para posicionar una v.
aa <- gapminder %>% dplyr::relocate(country, .after = lifeExp)
aa <- gapminder %>% dplyr::relocate(country, .before = lifeExp)



#- slide nº 30 -----------------------------------------------------------------
#- mutate() para crear nuevas variables
aa <- gapminder %>% mutate(GDP = pop*gdpPercap)

#- las podemos situar donde queramos [🌶]
aa <- gapminder %>% mutate(GDP = pop*gdpPercap, .after = country)
aa <- gapminder %>% mutate(GDP = pop*gdpPercap, .before = country)



#- slide nº 31 -----------------------------------------------------------------
#-  summarize() para "resumir" variables
aa <- gapminder %>% summarise(media = mean(lifeExp))  
aa <- gapminder %>% summarise(desviacion_tipica = sd(lifeExp))  
aa <- gapminder %>% summarise(max(pop))  
aa <- gapminder %>% summarise(NN = n())  
aa <- gapminder %>% count()      #- más adelante veremos la utilidad de count()

#- resumimos 2 variables
#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- gapminder %>% summarise(mean(lifeExp), mean(gdpPercap))

#- 2 resumenes de 1 variable
#- retornará 2 valores: la media y sd de la v. "lifeExp"
aa <- gapminder %>% summarise(mean(lifeExp), sd(lifeExp))




#- slide nº 32 -----------------------------------------------------------------
#- 6.B summarize() con across()

#- media de cada una de las 6 variables. Devuelve 2 warnings porque las 2 primeras son textuales. No se puede calcular la media de continent y country
gapminder %>% summarise(across(everything(), mean) ) 

#- calculamos la media de tercera a la sexta variable
gapminder %>% summarise(across(3:6, mean) )

#- Dentro de across() se puede utilizar where() para aplicar criterios lógicos para seleccionar variables: [🌶] [ 🌟 ]
gapminder %>% summarise(across(where(is.numeric), mean)) 

#- con los nombres de los argumentos (más largo pero conviene verlo de vez en cuando)
gapminder %>% summarise(across(.cols = where(is.numeric), .fns = mean))


#- slide nº 33 -----------------------------------------------------------------
#- summarize() con across() y varias funciones(list)

#- calculamos la media y desviación típica de las columnas 3 a 6.
gapminder %>% summarise(across(3:6, list(media = mean, desv = sd)))

#- lo mismo, pero explicitando los nombres de los argumentos [🌶] 
gapminder %>% summarise(across(.cols = 3:6, .fns = list(media = mean, desv = sd) ))

#- lo mismo otra vez, pero eligiendo el nombre de las variables que se van a crear con .names [🌶] [🌶] 
gapminder %>% summarise(across(3:6, list(media = mean, desv = sd), .names = "{fn}_{col}"))



#- slide nº 34 -----------------------------------------------------------------
#- group_by(). Con está función ya se puede ver la potencia de dplyr

aa <- gapminder %>% group_by(continent) %>% summarise(NN = n()) 
aa


#- slide nº 35 -----------------------------------------------------------------
#- Usando group_by()

aa <- gapminder %>% group_by(country) %>%  
  summarize(NN = n())

aa <- gapminder %>% group_by(continent) %>%  
  summarize(NN = n(), 
            NN_countries = n_distinct(country)) 
aa


#- slide nº 36 -----------------------------------------------------------------
#- Usando group_by()
aa <- gapminder %>% group_by(continent) %>%  
  summarize(NN = n(), 
            NN_countries = length(unique(country)) )
aa



#- slide nº 38 -----------------------------------------------------------------
#- Ejemplos para practicar con  `dplyr`



#- slide nº 39 -----------------------------------------------------------------
#- Más ejemplos (para recordar across())


#- slide nº 41 -----------------------------------------------------------------
#- ¿en que continente ha aumentado más la esperanza de vida en el periodo 1952-2007?



#- slide nº 44 -----------------------------------------------------------------
#- Más preguntas de verdad



#- COMBINANDO df's -------------------------------------------------------------
#- COMBINANDO df's -------------------------------------------------------------

#- slide nº 47 -----------------------------------------------------------------
#- 2 df's con las mismas filas
df_1 <- iris[ , 1:2]  ; df_2 <- iris[ , 3:5]
df_1 <- iris %>% select(1:2)  ; df_2 <- iris %>% select(3:5) 
df_3 <- bind_cols(df_1, df_2)
identical(iris, df_3)

#- 2 df's con las mismas columnas
df_1 <- iris[1:75, ]  ; df_2 <- iris[76:150, ]
df_1 <- iris %>% slice(1:75)  ; df_2 <- iris %>% slice(76:150) 
df_3 <- bind_rows(df_1, df_2)
identical(iris, df_3)


#- Mutating joins --------------------------------------------------------------
#- slide nº 49 -----------------------------------------------------------------
x <- tibble(id = 1:3, x = paste0("x", 1:3))
y <- tibble(id = (1:4)[-3], y = paste0("y", (1:4)[-3]))


#- slide nº 50 -----------------------------------------------------------------
