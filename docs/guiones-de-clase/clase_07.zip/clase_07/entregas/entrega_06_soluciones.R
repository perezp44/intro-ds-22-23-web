#- ENTREGA nº 06
#---- Pon tus datos de identificación ----------------------------
#- Apellidos:
#- Nombre:
#- e-mail:
#- NPA:
#-------------------------------------------------------------------------------
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
#-------------------------------------------------------------------------------
#- Solo has de subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, no hay que subir el Rproject, hay que subir solo el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_06_perez_pedro_GG445566.R
#-------------------------------------------------------------------------------

#- Objetivo: trabajar un poco más manejo de datos con dplyr, y en concreto algunas funciones como ifelse(), case_when(), is.na(), complete.cases() , entre otras
#- trabajaremos con datos de premios Nobel del proyecto "Tidy Tuesday"
#- los datos se pueden ver aquí: https://github.com/rfordatascience/tidytuesday/tree/master/data/2019/2019-05-14
#- para descargarlos hay que usar esta dirección: https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv

#- descarga los datos en "./datos/nobel_winners.csv"
el_url <- "https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv"
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
#download.file(el_url, archivo_de_destino)

#- para importar los datos a R. Podríamos hacerlo con rio::import(),
#- pero lo voy a hacer con readr::read_csv()
#- nos mostrará como se lee/interpreta cada columna (si es character etc...)
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
df_original <- readr::read_csv(archivo_de_destino)

#- ya tenemos los datos en el data.frame "df" trabajaremos sobre df para contestar una serie de preguntas y practicar con dplyr
rm(archivo_de_destino, el_url) #- borro lo q no nos hace falta

#- cargamos paquetes ------
library(tidyverse)

#- para visualizar mejor los datos voy a dejar solo 7 columnas
df <- df_original %>%
      select(birth_country, laureate_type, prize_year, birth_date, category, gender, full_name)


#- Pregunta 0) ------------------------------------------------------------------
# Se trata de que expliques que hacen las siguientes lineas de código.
#- Para ello tienes que escribir debajo de cada instrucción un comentario explicando lo que hace la instrucción de arriba.
#- En todos los comentarios pon el nº de filas de aa.
#- Yo comento la primera instrucción para q te sirva de ejemplo

aa <- df %>% filter(birth_country == "Spain")
#- seleccionamos las filas de los Nobeles ganados por españoles (aa tiene  7 filas). España solo ha ganado 7 Nobeles 6 de ellos en literatura) (Este comentario ya está hecho)

aa <- df %>% filter(birth_country != "Spain")
#- pon aquí tu comentario. trata de entender xq no salen (969-7) filas, sino bastantes menos, concretamente 936
#- Sí, la razón es que filter elimina las observaciones donde no se sabe el país de nacimiento. Sí, para que filter retenga una obervación deben cumplirse las condiciones (deben devolver un TRUE). OK, peroe las operaciones de comparación, los operadores de comparació,  devuelven un NA si hay un NA involucrado. Para entenderlo ejecuta
2 != NA  #- no sabemos si 2 es distinto de NA (xq el NA podría tomar el valor 2, xq no sabemos su valor y es posible q sea 2)


aa <- df %>% filter(birth_country != "Spain" | is.na(birth_country))
#- pon aquí tu comentario. Fíjate que ahora sí salen (969-7).
# Sí, ahora con las 2 condiciones conseguimos lo que pretendiamos, que era dejar todas las observaciones con Nóbeles que no son españoles (incluidos los q no sabemos de donde son: NA's)


aa <- df %>% filter(!(birth_country %in% c("Spain")) )
#- pon aquí tu comentario. Fíjate que ahora tb (969-7)
#- Con esta instrucción también se consigue lo que pretendíamos, que era dejar todas las observaciones con Nóbeles que no son españoles (incluidos los q no sabemos de donde son: NA's).



aa <- df %>% filter(birth_country %in% c("Spain", "France")) #- selecciona los nobeles ganados por FRA y ESP (60)

aa <- df %>% filter(!(birth_country %in% c("Spain", "France")) ) #- selecciona los nobeles que han sido ganados por otros países que no sean FRA y ESP (no se eliminan los NA's)

#- Tampoco le des muchas-muchas vueltas, hay que hacerlo en menos de 3 horas (lo siento!!). La intención del ejercicio es que trabajases un poco con el operador ! , y que vieses que los operadores"==" e  %in% no son exactamente iguales. la conclusión final es que cuando en tu df hay NA's hay que extremar las precauciones al seleccionar los casos/filas



#- Pregunta 1) -----------------------------------------------------------------
#- Muestra los 5 países con más Nobeles
#- Puedes usar n() o count() o ...
aa <- df %>%
      group_by(birth_country) %>%
      summarize(NN = n()) %>%
      slice_max(NN, n = 5) #- USA, UK, GER, FRA, SWE

aa <- df %>%
      count(birth_country, name = "NN")  %>%
      slice_max(NN, n = 5) #- USA, UK, GER, FRA, SWE

#- Pregunta 2) -----------------------------------------------------------------
#- seleccionar los 26 premios Nobel de los que no sabemos el país de nacimiento.
#- Pista: is.na()
aa <- df %>% filter(is.na(birth_country))
aa <- df %>% filter(laureate_type == "Organization") #- resulta que básicamente son los asignados a organizaciones


#- Pregunta 3) -----------------------------------------------------------------
#- Seleccionar los premios Nobel de los que SÍ sabemos el país de nacimiento.
#- Pista: !!!!!!
aa   <- df %>% filter(!is.na(birth_country)) #- devuelve 943 rows (es  la respuesta correcta)
aa_x <- df %>% filter(birth_country != "NA") #- nos devuelve el resultado correcto, PERO podría habernos dado problemas. 
aa_xx <- df %>% filter(birth_country != NA)  #-  devuelve cero rows. Los operadores de comparación que involucran a NAs devuelven NAs
#- CONCLUSION: Para identificar NAs usa la función is.na()

#- Un poco más de explicación: Es la misma situación de la pregunta 0). Como no hay ningun país que se llame "NA", entonces seleccionamos (de forma correcta) todas las filas donde sabemos el país de nacimiento del premiado, PERO podríamos haber obtenido un mal resultado si algún país se llamase "NA";
#- Explicación un poco más técnica: filter() se quedara con las filas que devuelvan un TRUE al evaluar la condición. La condición es birth_country != "NA". Cuando en una operación de comparación  (como ocurre con !=) está involucrado un NA, la evaluación de la comparación devolverá un NA, no devolverá ni TRUE ni FALSE, devolverá un NA: "los NAs son contagiosos, se propagan".
#- Conclusión, para detectar los NAs hay que utilizar la función is.na()


#- Pregunta 4) -----------------------------------------------------------------
#- Has de filtrar los casos completos; es decir, dejar solo las filas que no tienen ningún NA.
#- Pista: usa la función tidyr::drop_na(). Igual tenéis que mirar la documentación de la función. Los ejemplos suelen ser bastante ilustrativos

aa_1a <- df %>% tidyr::drop_na()                 #- (938)
aa_1b <- df %>% tidyr::drop_na(birth_country)    #- (943)

aa_2a <- df %>% filter(complete.cases(.))               #- (938)  complete.cases() es de R-base
aa_2b <- df %>% filter(complete.cases(.$birth_country)) #- (943)  complete.cases() es de R-base

aa_3a <- df %>% na.omit       #- (938) na.omit() es de R-base



#- Pregunta 5) -----------------------------------------------------------------
#- Para aquellos premios Nobel que no sabemos donde han nacido, suponemos y ponemos que han nacido en "Marte".
#- Pista: ifelse()

aa <- df %>% 
  mutate(birth_country = 
           ifelse(is.na(birth_country), "Marte", birth_country))

aa <- df %>% 
  mutate(birth_country = 
           if_else(is.na(birth_country), "Marte", birth_country))

aa <- df %>% 
  mutate(birth_country = 
           ifelse(is.na(df$birth_country), "Marte", df$birth_country))

#- Luis -------------------------------
#- hiciste esto
aa <- df # duplico el data frame
aa$birth_country <- replace(aa$birth_country, is.na(aa$birth_country),"Marte")
aa <- df
#- un R-base más purista
aa[is.na(aa$birth_country), "birth_country"] <- "Marte"


#- Pregunta 6) -----------------------------------------------------------------
#- Tenéis que crear una nueva variable llamada "my_comentario". Si el Nobel ha nacido en "Spain" ponemos "Olé!!". Si ha nacido en Francia ponemos "Très bien", y si ha nacido en "United States of America" ponemos "Wikidata mola". Para los de los demás países ponemos "NV Nobel ya!!"
#- Pista: la función que tenéis que usar es case_when(). Mira un ejemplo de ayuda y cópialo para empezar
aa <- df %>% 
  mutate(my_comentario =  case_when(
                        birth_country == "Spain"   ~ "Olé!!",
                        birth_country == "France"  ~ "Très bien",
                        birth_country == "United States of America" ~ "Wikidata mola",
                        TRUE ~ "NV Nobel ya!!")) %>%
          select(birth_country, my_comentario, everything() )


#- Pregunta 7) -----------------------------------------------------------------
#- Cuantos premios Nobel ha habido cada año:

aa <- df %>% group_by(prize_year) %>% summarise(NN = n())  #- cuantos premios hubo cada año
aa <- df %>% count(prize_year) %>% arrange(desc(n))        #- cuantos premios hubo cada año (ordenados por mayor nº a menor)

#- Pregunta 8) -----------------------------------------------------------------
#- Encontrar el año en el que un sólo país se ha llevado el mayor porcentaje de premios Nobel
#- Pista: hay q agrupar con group_by() 2 veces

aa <- df %>% 
  select(prize_year, birth_country) %>%
  group_by(prize_year) %>%
  mutate(n_nobel_ese_anyo = n()) %>%
  group_by(prize_year, birth_country) %>%
  mutate(n_nobel_ese_pais = n()) %>%
  mutate(percent_ese_anyo = n_nobel_ese_pais/n_nobel_ese_anyo)  %>%
  distinct() %>%  #- evitamos duplicados
  arrange(desc(percent_ese_anyo))



#- si quisiera dejar una sola observación por año
bb <- aa %>% 
  group_by(prize_year) %>% 
  summarise(Max = max(percent_ese_anyo, na.rm = TRUE))

#- lo de arriba esta ok, pero pierdo toda la información (solo dejo 2 columnas)
#- así que lo hago de otra manera
cc <- aa %>% 
    group_by(prize_year) %>% 
    #- las 2 lineas siguientes se podrían hacer con slice_max()
    arrange(desc(max(percent_ese_anyo, na.rm = TRUE))) %>% 
    slice(1) %>% 
    ungroup() %>% 
    arrange(desc(percent_ese_anyo))

#- Pregunta 9) -----------------------------------------------------------------
#- Encuentra el Nobel más viejo y el más joven
#- Venga, esta vez os ayudo: yo calculo la edad a la que recibieron el premio
str(df) #- la v "birth_date" es de tipo Date (fecha)
typeof(df$birth_date)
class(df$birth_date)
head(df$birth_date)            #- sí, salen como fechas
head(unclass(df$birth_date))   #- !!!!! sí las fechas en realidad-realidad es numerica, concretamente el nº de dias hasta 1970-01-01

library(lubridate) #- para trabajar con fechas el paquete lubridate
aa <- df %>%
  mutate(anyo_nac = lubridate::year(birth_date)) %>%
  mutate(edad = prize_year- anyo_nac) %>%
  select(prize_year, category, full_name, birth_country, birth_date, edad)

bb <- aa %>% 
  filter(edad == min(edad, na.rm = TRUE) | edad == max(edad, na.rm = TRUE))



#- Pregunta 10) -------------------------------------------------------------------------
#- Calcula la edad media por categoría
#- Warning: cuidado con los Na's al calcular la media

cc <- aa %>% group_by(category) %>%
  summarise(media_edad = mean(edad, na.rm = TRUE)) %>%
  arrange(media_edad)

#- Pregunta 11) -------------------------------------------------------------------------
#- calcula la categoría en la que han ganado más porcentaje de mujeres.

aa <- df %>% group_by(category, gender) %>% summarise(NN = n())

aa <- df %>% group_by(category, gender) %>% count(name = "NN", sort = TRUE)

aa <- df %>% count(category, gender, name = "NN", sort = TRUE)


bb <- aa %>% pivot_wider(names_from = gender, values_from = NN)

cc <- bb %>% mutate(percent_F = Female/ (Male + Female)) %>%
  arrange(desc(percent_F))

#- podría estar todo junto y sobra el primer group_by() xq usamos count()

aa <- df %>% 
  count(category, gender, name = "NN", sort = TRUE) %>% 
  pivot_wider(names_from = gender, values_from = NN) %>% 
  mutate(percent_F = Female/ (Male + Female)) %>%
  arrange(desc(percent_F))

#-La verdad es que para hacer tablas básicas no hace falta calentarse la cabeza. Podemos usar el pkg janitor. Lo veremos cuando hagamos EDA. Ejecuta las siguientes instrucciones y verás que fácil salen las tablas
#- Para otras cosas sí q es muy-muy necesario saber manejar datos con tidyverse
library(janitor)

df %>% tabyl(category)
df %>% tabyl(category, gender)
df %>% tabyl(category, gender) %>% adorn_percentages("row")
df %>% tabyl(category, gender) %>% adorn_percentages("row") %>% adorn_pct_formatting()

#- Pregunta 12) ----------------------------------------------------------------
#- Vamos a fusionar dos tablas, dos df's. Por favor fusiona df con gapminder.
#- Os ayudo:
#- Antes limpiamos el Global Env.
objetos_no_borrar <- c("df")
rm(list = ls()[!ls() %in% objetos_no_borrar])

#- cargamos gapminder en memoria.
gapminder <- gapminder::gapminder

#- simplificamos gapminder: dejamos solo 3 columnas de gapminder y solo el año 2007
gapminder <- gapminder %>% select(1, 3, 4) %>% filter(year == 2007)

#- simplifico df: dejo solo el año 2007 y quitamos alguna columna para que todo se vea mejor
df <- df %>% filter(prize_year == "2007") %>% select(- c(laureate_type, birth_date))

#- Tu TAREA: ---
#- vamos a fusionar df y gapminder la variable para poder fusionar es el nombre del país.
#- En df el nombre del país está en la columna "birth_country" y en gapminder el país está en la v. "country"
#- se pueden hacer distintos tipos de fusiones. veamos 3: left, inner y full
#- Explica con palabras que hacen las siguientes 3 expresiones

df_left_join <- left_join(df, gapminder, by = c("birth_country" = "country"))
#- tu explicación aquí: añade las columnas de gapminder a df; además se retienen solo las filas presenten en df


df_inner_join <- inner_join(df, gapminder, by = c("birth_country" = "country"))
#- tu explicación aquí: añade las columnas de gapminder a df; además se retienen solo las filas que esten en los 2 df's

df_full_join <- full_join(df, gapminder, by = c("birth_country" = "country"))
#- tu explicación aquí: añade las columnas de gapminder a df; además se retienen todas las filas que hay en df Ó en gapminder



#- Pregunta 13) ----------------------------------------------------------------
#- Para acabar la entrega_06, tienes que hacer un gráfico. Da igual si es de premios Nobel o no.
#- Podéis fusilar/copiar uno de esta galería: https://www.r-graph-gallery.com/
#- pero eso sí, explica con palabras que tipo de gráfico es y que variables y geom_xx estás usando








#- Si quieres hacer un gráficon los datos de los Nobeles, aquí tienes algunos:
#- https://twitter.com/hashtag/tidytuesday
#- https://twitter.com/PBecciu/status/1128345721634197505
#- https://twitter.com/CapandChange/status/1128380077690032128
#- https://twitter.com/jon_cole/status/1128326024792383488
#- https://twitter.com/FiskerBang/status/1128198912827895808
#- https://twitter.com/IamMRWani/status/1128190807620481024
#- https://twitter.com/dataknut/status/1128164352308072449
#- https://twitter.com/geokaramanis/status/1128391346597847040
#- https://twitter.com/oranwutan/status/1128643059116322817/photo/1   (el de las funciones de David Robinson)

#- generalmente David Robinson hace un screencast: https://www.youtube.com/channel/UCeiiqmVK07qhY-wvg3IZiZQ

#- ademas en Kaggle ya hubo una competición con estos datos: https://www.kaggle.com/nobelfoundation/nobel-laureates
#- aqui tienes dos ejemplos
# https://nbviewer.jupyter.org/github/shantel-martinez/shantel-martinez.github.io/blob/master/Rmd%20Protocols/TidyTuesdayWk20.html
# https://dataknut.github.io/tidytuesday/2019-05-14.html




#- ULTIMA TAREA:
#- borra (usando código) todos los archivos que haya en la carpeta "./datos/pruebas/"
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)
fs::file_delete(lista_de_archivos)

my_carpeta <- "./datos/pruebas"   #- con R-base (por si no tenéis instalado el paquete "fs")
lista_de_archivos <- list.files(my_carpeta, full.names = TRUE)
file.remove(lista_de_archivos)

