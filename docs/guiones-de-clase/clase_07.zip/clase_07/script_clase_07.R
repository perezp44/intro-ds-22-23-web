#- script para la clase_07: ggplot2
library(tidyverse)


#- plot base -------------------------------------------------------------------
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
        geom_point()
p

#- plot base con títulos -------------------------------------------------------
p <- p +
labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
    subtitle = "(diferenciando por especie de lirio)",
    caption = "Datos provenientes del Iris dataset",
    x = "Longitud del sépalo",
    y = "Longitud del pétalo",
    color = "Especie de lirio",
    tag = "Plot 1")
p

# enseguida continuamos con slides_06(B) pero antes RECORDAMOS un poco:
p <- ggplot(data = iris, 
            mapping = aes(x = Sepal.Length, 
                          y = Petal.Length, 
                          color = Species)) + 
          geom_point()
p
#- se pueden hacer tb cosas más "extrañas":
ggplot(iris, aes(Sepal.Length, Petal.Length, 
                   color = Petal.Length > 6)) +  geom_point()

ggplot(iris, aes(Sepal.Length, Petal.Length, 
                  color = Petal.Length > mean(Petal.Length, na.rm = TRUE))) + geom_point()


#- slides-06(B): ggplot2 más cosas ---------------------------------------------



#- Themes ----------------------------------------------------------------------
#- theme reference: https://ggplot2.tidyverse.org/reference/theme.html#ref-examples
#- see also: https://ggplot2.tidyverse.org/reference/theme.html#see-also
#- elemntos del theme: https://github.com/claragranell/ggplot2/blob/main/ggplot_theme_system_cheatsheet.pdf

p + my_theme
p + theme(panel.background = element_blank())
p + theme(panel.grid.major = element_line(color = "pink"))

p + theme(legend.position = "none")
p + theme(legend.position = "bottom")

theme_set(theme_minimal() + theme(axis.title.x = element_blank()))
p

args(theme)
theme_set(theme_gray() )
#- geom_text() -----------------------------------------------------------------
 p +   geom_label(aes(label = Petal.Length), nudge_x = 4)


#- colores ---------------------

paletteer::paletteer_c("scico::berlin", n = 10)
paletteer::paletteer_d("nord::aurora")

p + paletteer::scale_color_paletteer_d("nord::aurora")



#- anotaciones -----------------------------------------------------------------
p +
annotate(geom = "text",
  x= 6,
  y = 2,
  label = "Una anotación",
  size = 5)

help(annotate)    #- Run examples  (AQUI)


p +
geom_vline(xintercept = 6) +
geom_hline(yintercept = 5,
  size = 1.7,
  colour = "purple",
  linetype = "dashed")



#- cosas varias (no funcionan así en abstracto)
iris_2 <- iris %>% mutate(Petal_2 = ntile(Petal.Width, 2))


p + facet_grid(rows = vars(Species))    #- escalas comunes


p_twitter <- ggplot() + ggpubr::background_image(img_twitter) + coord_fixed() 



ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) +
geom_point() +
expand_limits(y = 0, x = 0) +
scale_x_continuous(expand = c(0, 0)) +
scale_y_continuous(expand = c(0, 0)) +
geom_vline(xintercept = 0) +
geom_hline(yintercept = 0)