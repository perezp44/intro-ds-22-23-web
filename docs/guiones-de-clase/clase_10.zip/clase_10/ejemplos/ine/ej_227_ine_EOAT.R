#- no es estadistica experimental, 
#- es la Encuesta de ocupación en alojamientos turísticos extrahoteleros. EOAT. Febrero 2021: 
#- https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736176962&menu=ultiDatos&idp=1254735576863
#- voy a RESULTADOS. MENSUALES: Encuesta de ocupación en apartamentos turísticos. Nacional, ccaa, provincias, zonas y puntos turísticos: https://www.ine.es/dynt3/inebase/index.htm?padre=232
#- Dentro hay 18 tablas. Bajo la tabla 16:  Plazas, apartamentos, grados de ocupación y personal empleado por puntos turísticos


library(tidyverse)
#- tabla 16 (Plazas, apartamentos, grados de ocupación y personal empleado por puntos turísticos)
my_url <- "https://www.ine.es/jaxiT3/files/t/es/px/2083.px?nocab=1"

df_orig <- pxR::read.px(my_url) %>% as.data.frame %>% as_tibble 
df <- df_orig %>% janitor::clean_names()

zz <- pjpv2020.01::pjp_f_valores_unicos(df_orig, nn_pjp = 120)

df <- df %>% dplyr::rename(variables = establecimientos_y_personal_empleado_plazas)

df <- df %>% tidyr::separate(periodo, into = c("year", "mes"), sep = "M", extra = "merge", remove = TRUE)
df <- df %>% tidyr::separate(puntos_turisticos, into = c("ine_code", "ine_code.n"), sep = " ", extra = "merge", remove = TRUE)
  

df <- df %>% mutate(variables = case_when(
  variables == "Número de plazas estimadas" ~ "plazas_estimadas",
  variables == "Número de apartamentos estimados" ~ "apartamentos_estimados",
  variables == "Grado de ocupación por plazas" ~ "ocupacion_plazas",
  variables == "Grado de ocupación por apartamentos" ~ "ocupacion_apartamentos",
  variables == "Grado de ocupación por apartamentos en fin de semana" ~ "ocupacion_apartamento_weekend",
  variables == "Personal empleado" ~ "personal_empleado"))

df <- df %>% pivot_wider(names_from = variables, values_from = value)
zz <- pjpv2020.01::pjp_f_valores_unicos(df, nn_pjp = 120)

unique(df$ine_code)


zz1 <- df %>% 
  filter(year %in% c(2021, 2019)) %>% 
  filter(mes %in% c("01", "02")) 
