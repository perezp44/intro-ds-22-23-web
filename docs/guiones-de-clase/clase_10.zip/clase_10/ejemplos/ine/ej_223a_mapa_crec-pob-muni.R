#- quiero hacer un mapa con el crecimiento de la población en el periodo 2000-2020
library(tidyverse)
library(sf)

# datos ----
geo_muni <- pjpv.curso.R.2022::LAU2_muni_2020_canarias
pob_2000_2020 <- pjpv.curso.R.2022::ine_pob_mun_1996_2021
  


#- crecimiento de la población en España 2000-2020
crec_esp <- pob_2000_2020 %>% 
  filter(year %in% c(2000, 2020)) %>% 
  filter(poblacion == "Total") %>% 
  select(year, values) %>% 
  group_by(year) %>% 
  summarise(habitantes = sum(values)) %>% 
  mutate(crec_abs = habitantes - lag(habitantes)) %>% 
  mutate(crec_percent = crec_abs /lag(habitantes)) %>% ungroup()

#- la pob. española creció un 17,16% en 2000-2020
media_crec_esp <-  crec_esp[[2,4]]*100
rm(crec_esp)

#- vamos a calcular el crecimiento de población a nivel MUNICIPAL (2000-2020)

#- filtro y selecciono lo que necesito
pob_muni <- pob_2000_2020 %>% 
  filter(year %in% c(2000, 2020)) %>% 
  filter(poblacion == "Total") %>% 
  select(-c(ine_muni.n.orig, ine_ccaa, ine_ccaa.n, capital_ccaa, poblacion)) %>%
  rename(habitantes = values) %>% 
  arrange(ine_muni)

#- paso a formato ancho (una columna para 2000 y otra para 2020)
pob_muni <- pob_muni %>% 
  pivot_wider(names_from = c("year"), values_from = c("habitantes")) 

#- calculo crecimiento de población a nivel municipal (2000-2020)
pob_muni <- pob_muni %>% 
  mutate(crec_2020_2000 = `2020`- `2000`) %>% 
  mutate(crec_porcentual = (`2020`- `2000`) / `2000` *100) %>% 
  arrange(desc(crec_porcentual)) 

#- creo mas variables: crec_porcentual.n, crec_porcentual.f
pob_muni <- pob_muni %>% 
  mutate(crec_porcentual.n = paste0(round(crec_porcentual, digits = 1), "%")) %>% 
  mutate(crec_porcentual.f = as_factor(case_when(
    crec_porcentual < 0 ~ "Negativo",
    between(crec_porcentual, 0, media_crec_esp) ~ "< media",
    crec_porcentual > media_crec_esp ~ "> media")))

#- reordeno los levels de crec_porcentual.f
pob_muni <- pob_muni %>% 
  mutate(crec_porcentual.f = fct_relevel(crec_porcentual.f, "Negativo", "< media"))

#- theme -----------------
my_theme_maps <- pjpv.curso.R.2022::theme_pjp_maps()
#- settings --------------------------------------------------------------------
#- elijo df con geometrías, df con variables 
my_geo <- geo_muni                      #- AQUI-AQUI
my_variables <- pob_muni                #- AQUI-AQUI
my_geo <- inner_join(my_geo, my_variables)  
#- elección de variables q voy a gráficar
my_vv <- expr(crec_porcentual.f)    #- AQUI-AQUI   (fill y leyenda)
my_vv_2 <- expr(crec_porcentual.n)  #- AQUI-AQUI  (para el geom_text(label)). Solo se usa para ceuta y melilla


#- plot inicial
p <- ggplot() + 
  geom_sf(data = my_geo, 
          aes(geometry = geometry, fill = !!my_vv), 
          color = "white", size = 0.09) 

#- mejoramos un poco
p <- p + my_theme_maps +
    labs(title = "Crecimiento de la población municipal (2000-2020",
       fill = "Cremiento población") 

p
#- vamos a dejarlo como: https://perezp44.github.io/pjperez.web/posts/2021-02-10-poblacion-municipal/imagenes/2021_02_10_poblacion_municipal_01.png


#- nos hace falta: -------------------------------------------------------------
#- un shape para la costa marroquí
#- los contornos provinciales
#- situar las capitales de provincia (puntos con long-lat)
#- ponerle un cuadrito a Canarias
#- y mejorar los títulos y anotaciones

#- Marruecos (un shape para la costa marroquí)
geo_morocco <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf") %>% 
  dplyr::filter(sovereignt %in% c("Morocco")) %>% select(sovereignt)

#- contornos provinciales
geo_prov <- pjpv.curso.R.2022::LAU2_prov_2020_canarias

#- situación (X, Y) de las capitales provinciales
capitales <- pob_muni %>% 
  filter(capital_prov == "Sí") %>% 
  left_join(. , st_drop_geometry(geo_muni)) %>% 
  mutate(capital_prov.2 = ifelse(capital_prov == "Sí", "Capital provincial", "NO"))

#- ceuta y melilla
ceuta <- my_geo %>% filter(ine_ccaa %in% c(18,19))

#- me va a hacer falta para hacer el cuadrito para Canarias
my_canarias <- my_geo %>% 
  filter(ine_ccaa == "05") #- solo para el cuadrito, no para las geo



#- 
p <- p +
  geom_sf(data = geo_morocco, aes(geometry = geometry)) +
  geom_point(data = capitales, aes(x = X, y = Y), color = "black") +
  geom_text(data = ceuta, aes(x = X1+0.1, y = Y1, label = !!my_vv_2), #- v. continua
            color = "black",  
            check_overlap = TRUE, size = 3)  #- fontface = "bold"
  
p

#- tenemos q. hacer un zoom
p <- p +  
  coord_sf(xlim = c(st_bbox(my_geo)[1]-0.2, st_bbox(my_geo)[3]+0.3), 
           ylim = c(st_bbox(my_geo)[2]-0.1, st_bbox(my_geo)[4]+0.3), expand = FALSE)

p

#- el cuadrito en Canarias
p <- p +
  geom_rect(aes(xmin = st_bbox(my_canarias)[1]-2.5, 
                xmax = st_bbox(my_canarias)[3]+0.1, 
                ymin = st_bbox(my_canarias)[2]-2.5, 
                ymax = st_bbox(my_canarias)[4]+0.1), 
            fill = NA, colour = "black", size = 0.3, 
            show.legend = FALSE, linejoin = "round", linetype = 2) 
  
p

#- mejoramos cosas

janitor::tabyl(pob_muni, crec_porcentual)
my_subtitle <- glue::glue(
  "En 2000-2020, la población en España creció un 17,16%.
   Por municipios, un 63% presentaron un <span style='color:#ee3b3b'>crecimiento negativo</span>,\n
   un 15% tuvieron un <span style='color:#8ee5ee'>crecimiento inferior a la media</span> española, mientras que 1.806 municipios,\n
   un 22%, presentaron <span style='color:#9acd32'>crecimiento superior a la media</span>.")

#- colores del fill
p <- p +
  scale_fill_manual(name = NULL,  
                    values = c("#ee3b3b", "#8ee5ee",  "#9acd32"))
p

#- mejoramos el título y sobre todo el subtitulo
p <- p + my_theme_maps + 
  labs(title = "Crecimiento de la población municipal: 2000-2020",
       subtitle = "En 2000-2020, la población en España creció un 17,16%",
       x = "", 
       y = "",
       caption = "Datos de población del INE. 
       Geometrías del paquete LAU2boundaries4spain. Visualización: @pjpv4444")
p  

#- mejoramos el subtitulo
  
zz <- janitor::tabyl(pob_muni, crec_porcentual.f)
zz

my_subtitle <- glue::glue(
  "En 2000-2020, la población en España creció un 17,16%.
   Por municipios, un 63% presentaron un <span style='color:#ee3b3b'>crecimiento negativo</span>,\n
   un 15% tuvieron un <span style='color:#8ee5ee'>crecimiento inferior a la media</span> española, mientras que 1.806 municipios,\n
   un 22%, presentaron <span style='color:#9acd32'>crecimiento superior a la media</span>.")

p <- p + 
  labs(subtitle = my_subtitle) +
  theme(plot.subtitle = 
          ggtext::element_markdown(size = 11, family = "Roboto Condensed", 
                                   face = "bold", color = "dimgrey")) 
p


#- los límites provinciales

p1 <- p +
  geom_sf(data = geo_prov, aes(geometry = geometry), fill = NA, color = "black") 
  
p1  #- !!!!!!!!

#- al poner otra geometría hemos de volver a hacer zoom 
my_limites <- coord_sf(xlim = c(st_bbox(my_geo)[1]-0.2, st_bbox(my_geo)[3]+0.3), 
         ylim = c(st_bbox(my_geo)[2]-0.1, st_bbox(my_geo)[4]+0.3), expand = FALSE)
p <- p +
  geom_sf(data = geo_prov, aes(geometry = geometry), 
          fill = NA, color = "black", lwd = 0.1) +
  my_limites
  

p

#- ponemos cuadro con anotaciones/explicaciones
my_textito <- glue::glue("Los municipios con crecimientos de población <B><span style='color:#9acd32'>superiores a la media</span>,</B> se concentran a lo largo de la costa mediterranea, Baleares, Canarias, área de influencia de Madrid y en menor medida en el País Vasco")

p <- p + 
  ggtext::geom_textbox(aes(label = my_textito, x = -12.1, y = 40.0), 
                        color = "black", size = 3.5, 
                        width = grid::unit(0.25, "npc"),
                        fill = "white", box.color = "black", 
                        family = "Tahoma", hjust = 0L)

# p <- p + theme(plot.margin = margin(t = 0.5, r = -0.9, b = 0.5, l = -2.1, "cm"))
# p <-   p + theme(plot.margin = unit(c(0.4, 0.5, 0.4 , -6.5), "cm"))

#- para guardar el plot
ggsave(p, filename = here::here("pruebas", "plot_poblacion_municipal_01.png"),
       device = "png", width = 29, height = 20, units = "cm")
#knitr::plot_crop(here::here("pruebas", "plot_poblacion_municipal_02.png"))

magick::image_read(here::here("pruebas", "plot_poblacion_municipal_01.png"))


#- para ver el plot que hemos guardado. Lo guarda en un tmp y lo visualiza
#- remotes::install_github("jdtrat/savory")
savory::ggpreview(width = 29, height = 20)
#- Add-ons
#- prueba: devtools::install_github("gadenbuie/ggpomological", build_vignettes=TRUE)
# library(ggpomological)
# p <- p + 
#   scale_fill_pomological() +  theme_pomological("Homemade Apple", 16) 
# 
# 
# ggimage::ggbackground(p, ggpomological:::pomological_images("background"))
