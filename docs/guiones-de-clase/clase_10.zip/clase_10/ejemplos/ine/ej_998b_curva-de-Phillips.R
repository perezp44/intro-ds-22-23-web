#- Curva de Phillips: https://en.wikipedia.org/wiki/Phillips_curve
#- https://www.lavanguardia.com/economia/20220605/8317351/inflacion-paro.html

#- https://twitter.com/ThomIvar/status/1516114838996631563
#- source: https://github.com/TIvanDijk/pRojects/blob/main/30DayChartChallenge/oecd.R

library(tidyverse)
library(eurostat)
library(ggtext)

#- Para descargar datos de inflación y tasa de desempleo podemos usar el pkg "eurostat" o "OECE" o ... 
#- my_table <- "prc_hicp_manr"        #- inflación de eurostat
#- web de la OCDE: http://stats.oecd.org/
#- library(OECD)   #- pkg OEDE: https://github.com/expersso/OECD
# dataset_list <- OECD::get_datasets()  #- df con listado de datos disponibles en OECD (1.526)
# aa <- OECD::search_dataset("unemployment") #- busqueda de datos sobre "unemployment" (10)


#- PERO usaremos los datos originales de @ThomIvar
#- Importamos los datos de Thom-Ivar van Dijk (@ThomIvar)
ruta_inflation <- "https://raw.githubusercontent.com/TIvanDijk/pRojects/main/30DayChartChallenge/other/oecd_inflation.csv"
inflation <- rio::import(ruta_inflation) 

ruta_unemployment <- "https://raw.githubusercontent.com/TIvanDijk/pRojects/main/30DayChartChallenge/other/oecd_unemployment.csv"
unemployment <- readr::read_csv(ruta_unemployment)


#- arreglamos los datos --------------------------------------------------------
inflation <- inflation %>% 
  dplyr::filter(FREQUENCY == "M" & MEASURE == "AGRWTH", SUBJECT == "TOT") %>% 
  select(place = LOCATION, date = TIME, cpi = Value)

unemployment <- unemployment %>% 
  dplyr::filter(FREQUENCY == 'M', SUBJECT == 'TOT') %>% 
  select(place = LOCATION, date = TIME, rate = Value)

#- fusionamos los 2 df's -------------------------------------------------------
df <- left_join(inflation, unemployment) %>% 
  tidyr::drop_na() %>% 
  dplyr::filter(place == 'G-7') %>% 
  dplyr::mutate(group = case_when(
    str_starts(date, "200") ~ "2000-2009", 
    str_starts(date, "201") ~ "2010-2019", 
    TRUE ~ "other" )) %>% 
  dplyr::filter(group != "other")

# -- make plot
p0 <- ggplot(df, aes(x = rate, y = cpi, group = group, color = group)) +
        geom_point(alpha = 0.5, size = 2.25) 
p0

p1 <- p0 + geom_smooth(method = 'lm', se = FALSE, linetype = 2)
p1

p1 + scale_color_manual(values = c('#d1495b', '#00798c'))
  

p1 + scale_color_manual(values = c('#d1495b', '#00798c')) +
  annotate('text', x = 5.5, y = 3.75, label = '2000-2009', color = '#d1495b', 
           family = 'American Typewriter', fontface = 'bold') +
  annotate('text', x = 4.5, y = 0.75, label = '2010-2019', color = '#00798c', 
           family = 'American Typewriter', fontface = 'bold') +
  labs(title = 'What happened to the <b>Phillips Curve</b>?', 
       subtitle = "The Phillips curve is an economic concept that states that inflation
       and unemployment have a stable and inverse relationship. According to this concept, 
       lower unemployment rates cause firms to raise wages to attract new labor, 
       which increases the inflation rate. However, in the <b style='color:#00798c'>
       last decade</b> this relationship appears to have vanished.", 
       caption = '@ThomIvar • source: OECD (monthly, G7 countries)', 
       x = 'Unemployment rate, %', 
       y = 'Inflation rate, %') +
  theme_void() +
  theme(
    text = element_text('American Typewriter', color = 'grey30'),
    legend.position = 'none', 
    plot.title = element_textbox_simple(size = 20, margin = margin(b = 0.15, unit = 'cm')),
    plot.subtitle = element_textbox_simple(size = 11, color = 'grey60', 
                                           margin = margin(b = 0.25, unit = 'cm')),
    plot.background = element_rect(fill = '#fffef7', color = '#fffef7'), 
    plot.caption = element_text(size = 10, color = 'grey80'),
    plot.margin = margin(1, 1, 1, 1, 'cm'), 
    panel.grid = element_line(color = 'grey70', linetype = 'dotted'), 
    axis.title = element_text(margin = margin(t = 0.2, r = 0.2, unit = 'cm'), color = 'grey50'), 
    axis.title.y = element_text(angle = 90),
    axis.text = element_text(color = 'grey70', size = 9,
                             margin = margin(t = 0.1, r = 0.1, unit = 'cm')),
    axis.line = element_line(color = 'grey50'), 
    axis.ticks = element_line(color = 'grey50', size = 0.6), 
    axis.ticks.length = unit(0.10, 'cm')
  )



#ggsave("./imagenes/oecd.png", width = 9.5, height = 6) 

#- COSAS NUEVAS ----------------------------------------------------------------
#- COSAS NUEVAS ----------------------------------------------------------------

#--- dejo solo lo esencial en el gráfico
p0 <- ggplot(df, aes(x = rate, y = cpi, color = group)) +
  geom_point() +
  geom_smooth(method = 'lm', se = FALSE)

p0

#- jugamos un poco con el theme() , con los elementos visuales
p1 <- p0 + scale_color_manual(values = c('#d1495b', '#00798c'))
p1

p1 + theme_void()

p1 + theme_void() + 
theme(legend.position = 'none', 
  plot.background = element_rect(fill = '#fffef7', color = '#fffef7'), 
  plot.margin = margin(1, 1, 1, 1, 'cm'), 
  panel.grid = element_line(color = 'pink', linetype = 'dotted'), 
  axis.line = element_line(color = 'pink'), 
  axis.ticks = element_line(color = 'grey50', size = 0.6), 
  axis.ticks.length = unit(1.10, 'cm')
)



#- EDA con ggplot --------------------------------------------------------------
#- voy a volver a hacer el grafico pero para varios paises
#- fusionamos los 2 df's -------------------------------------------------------
my_paises <- c("ESP", "FRA", "GBR", "DEU", "USA", "JPN")

df <- left_join(inflation, unemployment) %>% 
  tidyr::drop_na() %>% 
  # dplyr::filter(place == 'G-7') %>% 
   dplyr::filter(place %in% my_paises) %>% 
  dplyr::mutate(group = case_when(
    str_starts(date, "200") ~ "2000-2009", 
    str_starts(date, "201") ~ "2010-2019", 
    TRUE ~ "other" )) %>% 
  dplyr::filter(group != "other")


#- facetting
p0 <- ggplot(df, aes(x = rate, y = cpi, color = group)) +
  geom_point(alpha = 0.5, size = 0.75) +
  geom_smooth(method = 'lm', se = FALSE, linetype = 1) +
  scale_color_manual(values = c('#d1495b', '#00798c')) 
  
p0

p0 +  facet_wrap(vars(place)) 

p0 + facet_wrap(vars(place), scales = "free")  


#- borramos todo excepto df
no_quitar <- c("df")
rm(list=ls()[! ls() %in% no_quitar])


#- LOOPs  ----------------------------------------------------------------------
#- LOOPs  ----------------------------------------------------------------------

for (ii in 1:6) {
print(ii + 1)
  
}

#- MRLM ------------------------------------------------------------------------

#- creamos vector con nombres de los paises q voy a analizar
my_paises <- df %>% distinct(place) %>% pull()
my_paises <- unique(df$place)
my_paises <- c("ESP", "FRA", "GBR", "DEU", "USA", "JPN")


df <- df %>% 
  dplyr::filter(place %in% my_paises) %>% #- me quedo solo con algunos paises
  mutate(group = as_factor(group))   #- la v.group la pasamos a factor

  
#- loop para estimar varios modelos (1 por país)
for (ii in seq_along(my_paises)) {
  print(paste("Modelo para ", my_paises[ii], "  ---------------"))
  zz <- df %>% filter(place == my_paises[[ii]])
  zz_model <- lm(data = zz, cpi ~ rate + group)
  print(summary(zz_model))
  }

#- veamos un modelo 
my_model <- lm(cpi ~ rate + group, data = df)
summary(my_model)
broom::tidy(my_model)   #- el pkg broom del tidyverse es util


rm(my_model, zz, zz_model)
#------------------------------------------- [🌶🌶🌶][ 🌟 ]
#- en lugar de usar loops voy a crear un df con list-columns
#- creo un list-column df con nest (crea la columna data con los datos de cada pais)
#- https://cran.r-project.org/web/packages/broom/vignettes/broom_and_dplyr.html

df_by_pais <- df %>% dplyr::nest_by(place)  

#- creamos nueva columna que almacenará modelos para cada pais
my_modelos <- df_by_pais %>% mutate(mod = list(lm(cpi ~ rate + group, data = data)))

#- creamos las predicciones
my_modelos <- my_modelos %>% mutate(pred = list(predict(mod, data)))

#- veamos algunos resultados
my_modelos %>% summarise(rsq = summary(mod)$r.squared)      #- R-cuadrado
my_modelos %>% summarise(rmse = sqrt(mean((pred - data$cpi) ^ 2))) #- RMSE

my_modelos %>% summarise(broom::glance(mod)) #- medidas de "ajuste" de los modelos
my_modelos %>% summarise(broom::tidy(mod)) #- los coeficientes

#- lo mismo de otra forma 
df_TT <- df %>%
  tidyr::nest(data = -place) %>% 
  mutate(fit = map(data, ~ lm(cpi ~ rate + group , data = .x)),
          tidied = map(fit, broom::tidy)) %>% 
  tidyr::unnest(tidied)


df_TT2 <- df_TT %>% filter(term == "rate")
