#- un ejemplo de creación de tablas con gt
#- gt cookbook: https://themockup.blog/static/gt-cookbook.html#Conditional_formatting
#- advanced cookbook: https://themockup.blog/static/gt-cookbook-advanced.html
#- https://www.liamdbailey.com/post/making-beautiful-tables-with-gt/
#- https://aosmith16.github.io/spring-r-topics/slides/week04_gt_tables.html#1
#- https://aosmith16.github.io/spring-r-topics/slides/week05_gt_flair.html#1
#- https://github.com/rich-iannone/gt-workshop
#- https://posit.co/blog/changes-for-the-better-in-gt-0-6-0/
#- https://www.rstudio.com/blog/all-new-things-in-gt-0-7-0/
#- https://themockup.blog/posts/2022-06-13-gtextras-cran/
#- gtsummary: https://www.danieldsjoberg.com/clinical-reporting-gtsummary-rmed/material.html
#- Gallery of tables: https://community.rstudio.com/c/table-gallery/64
#- gallery en post: https://posit.co/blog/rstudio-community-table-gallery/
#- ganadores 2022: https://twitter.com/rstudio/status/1471504527941464064
#- post para echar sermon: https://www.liamdbailey.com/post/making-beautiful-tables-with-gt/
#- table batles Iannone y Kierisi: https://www.youtube.com/watch?v=tIB_N0nUfNs   kierisi: https://youtu.be/-c_PUee8Cu0        
#- gt video tutorial de iannone: @kierisi: https://youtu.be/z0UGmMOxl-c

library(tidyverse)
library(gt)
options(scipen = 999) #- para quitar la notación científica


#- cargamos datos para generar algunos resultados y mostrarlos en tablas
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/PIAAC_data_small.csv"
df <- read_csv(my_url)


#- 
#- tt_6 ------------------------------------------------------------------------
#- Calculamos la media, el mínimo, el máximo y la desviación típica de Wage_month
df <- df %>% 
  group_by(Country) %>% 
  summarise(W_medio  = mean(Wage_month, na.rm = TRUE) ,
            W_minimo = min(Wage_month, na.rm = TRUE)  ,
            W_maximo = max(Wage_month, na.rm = TRUE)  ,
            W_sd = sd(Wage_month, na.rm = TRUE) ) %>% 
  ungroup()

#- creamos una gt_table --------------------------------------------------------
tt_6 <- df %>% gt()
tt_6 <- gt::gt(df)
tt_6

#- PERO, así no la podemos presentar, así que ... vamos a jugar con ella para aprender a usar un poco `gt`
#- Antes de empezar hay q saber un poco como se llaman los distintos elementos de un `gt-table`
#- Para ello: https://gt.rstudio.com/


#- mejor decirle q columna contiene los nombres de las filas
tt_6 <- df %>% gt(rowname_col = "Country")
tt_6


#- vamos a ir añadiendo elementos /tuneando la tabla

#- títulos ---------------------------------------------------------------------
#- con tab_header() 
tt_6 <- tt_6 %>% 
  tab_header(title = "Salario en 4 países",
             #- fíjate q si usas md() puedes formatear con sintáxis markdown
             subtitle = md("*sixth round* of **PIACC**"))   

tt_6

#- notas al pie en el table footer ---------------------------------------------
#- con tab_source_note()
tt_6 <- tt_6 %>% 
  tab_source_note(md("Fuente: datos de [PIAAC](http://www.oecd.org/skills/piaac/)")) %>%
  tab_source_note(md("Obtenidos a partir del paquete RPIAAC"))
tt_6


#- nota al pie en los valores de la tabla
#- con tab_footnote() y cell_body() para seleccionar q celdas marcar
tt_6 <- tt_6 %>% 
  tab_footnote(footnote = "salario en libras", 
               location = cells_body(columns = W_medio, rows = 3)) %>% 
  tab_footnote(footnote = "Bufff!!!", 
               location = cells_body(columns = W_sd, rows = c(1,4)), 
               placement = "left") 
tt_6


#- The cols_*() functions allow for modifications of entire columns ------------

#- podemos cambiar los labels/titulos de las columnas con cols_label()
tt_6 <- tt_6 %>% cols_label(W_maximo = "Max.", 
                            W_minimo = "Min.") 
tt_6  

#- se puede usar MD en los nombres, dentro de md()
tt_6 <- tt_6 %>% cols_label(W_medio = md("**W medio**"))
tt_6
  
#- alineación de las columnas
#- Cuidado!!: Cambiar los labels no hace q cambien los nombres de las v./columnas del df
tt_6 <- tt_6 %>% cols_align(align = "center") %>% 
                 cols_align(align = "left", columns = c("W_medio"))
tt_6

#- las columnas se pueden mover
tt_6 <- tt_6 %>% cols_move(columns = c(W_minimo, W_maximo), 
                           after = c(W_sd))
tt_6


#- Puedes controlar la anchura de las columnas
#- con cols_width() en pixels (px()) o % of the current size (pct()) 
tt_6 <- tt_6 %>% 
  cols_width(columns = c(W_medio) ~ px(120)) 
  
tt_6  


#- se pueden combinar columnas
tt_6 <- tt_6 %>% 
  cols_merge(columns = c(W_minimo, W_maximo), pattern = "[{1} - {2}]")
tt_6

tt_6 <- tt_6 %>% cols_label(W_minimo = "Rango") 
tt_6  

#- con fmt_*() puedes dar formato a los valores de la tabla.
#- hay una familia de funciones fmt_*
tt_6 <- tt_6 %>% 
  fmt_number(columns = c(W_medio, W_sd),
             decimals = 1, 
             sep_mark = ".", 
             dec_mark = ",") 
tt_6

#- añadir filas de totales o medias o .... -------------------------------------
tt_6 <- tt_6 %>% 
  summary_rows(columns = c(W_medio),
               fns = list(Media = ~ mean(., na.rm = TRUE)))

tt_6

#- agrupando columnas con tab_spanner(). 
tt_6 <- tt_6 %>% 
  tab_spanner(label = "Cols. agrupadas",
              columns = c(W_sd, W_minimo) )
tt_6


#- el"theme" de la tabla -------------------------------------------------------

tt_6 <- tt_6 %>% 
  opt_row_striping() %>% 
  opt_table_font(font = google_font("Fira Mono")) %>% 
  tab_options(column_labels.border.bottom.color = "purple",
              table_body.border.bottom.color = "green",
              table_body.hlines.color = "orange")
tt_6

tt_6 <- tt_6 %>% 
  opt_row_striping() %>% 
  opt_table_font(font = google_font("Fira Mono")) %>% 
  tab_options(column_labels.border.bottom.color = "black",
              table_body.border.bottom.color = "black",
              table_body.hlines.color = "white") %>% 
    opt_align_table_header(align = "left") # left align header


#- hay una ff. q funciona como un theme
tt_6 %>% opt_stylize(style = 1, color = "cyan")  #- red

#- guardando la tabla ----------------------------------------------------------
gtsave(tt_6, "./pruebas/tt_6.rtf")
gtsave(tt_6, "./pruebas/tt_6.html")
gtsave(tt_6, "./pruebas/tt_6.docx")

#- guardando la tabla como imagen (hay q instalar el pkg "webshot2")
gtsave(tt_6, "./pruebas/tt_6.png")

#- tb hay familia de ff. as_latex() as_word()

#- añadiendo colores a celdas --------------------------------------------------
tt_6 <- tt_6 %>% 
         tab_style(style = cell_fill(color = "lightblue"),
                   locations = cells_body(columns = W_medio,
                                          rows = W_medio >= mean(W_medio)))  %>% 
         tab_style(style = cell_text(color = "red"),
            locations = cells_body(columns = W_medio,
                                   rows = W_medio >= mean(W_medio))) %>% 
         tab_style(style = cell_borders(color = "orange", weight = px(10)),
            locations = cells_body(columns = W_minimo,
                                   rows = W_minimo > 115))
tt_6  
  



#- añadiendo colores -----------------------------------------------------------

tt_6 <- tt_6 %>% 
  #- coloreamos en escala de verde la columna "W_medio". Toda la columna (domain = NULL)
  data_color(columns = c(W_medio),
    colors = scales::col_numeric(palette = "Greens", domain = NULL) ) %>% 
  #- coloreamos en escala de rojo la columna "W_sd". solo los valores entre 500 y 900
  data_color(columns = c(W_sd),
    colors = scales::col_numeric(palette = "Reds", domain = c(500, 900))) %>% 
  data_color(columns = c(W_minimo),
      colors = scales::col_numeric(palette = c("yellow", "purple"), domain = c(112, 150)),
             alpha = .6)
tt_6
    


#- incluyendo imágenes de internete---------------------------------------------
urls_fotitos <- c("https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Pancrudo_%2CCervera_del_Ric%C3%B3n_.Teruel.jpg/266px-Pancrudo_%2CCervera_del_Ric%C3%B3n_.Teruel.jpg",
                 "https://images.pexels.com/photos/97082/weimaraner-puppy-dog-snout-97082.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
                 "https://images.pexels.com/photos/35629/bing-cherries-ripe-red-fruit.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500",
                 "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Nacho_Vegas_Fib.jpg/800px-Nacho_Vegas_Fib.jpg")

df_img <- cbind(df, urls_fotitos) #- añadimos columna con ruta a la imagen
df_img <- df %>% mutate(urls_fotos = urls_fotitos) #- otra forma de hacerlo

tt_img <- df_img %>% gt() #- creamos la tabla tt_img a partir del df df_img
tt_img  #- uff!! solo se ve la ruta!!!

tt_img %>% 
  gt::text_transform(locations = cells_body(columns = c(urls_fotos)), 
                     fn = function(x){gt::web_image(x, height = 30)})

#- incluyendo imagenes (locales) -----------------------------------------------
#- habría q usar local_image() si la imagen estuviese en local

img_locales <- c("./imagenes/f3.png", 
                 "./imagenes/f4.png", 
                 "./imagenes/f1.webp", 
                 "./imagenes/f2.webp")

df_img <- cbind(df, img_locales)  #- añadimos columnas con ruta a la imagen
tt_img <- df_img %>% gt() #- creamos la tabla tt_img a partir del df df_img
tt_img #- lo mismo, solo se ven las rutas a los archivos locales

tt_img %>% 
  gt::text_transform(locations = cells_body(columns = c(img_locales)), 
                     fn = function(x){gt::local_image(x, height = 30)})




#- insertar columna con las imágenes de las banderas ---------------------------
library(countrycode) #- muy útil para mapas
df_continente <- df %>% mutate(continente = countrycode(sourcevar = Country, origin = "iso3c", destination = "continent"))
rm(df_continente)
library(glue)  #- muy util para trabajar con texto

#- resulta q aquí: https://hatscripts.github.io/circle-flags/  tenemos las banderas de los países (en código iso2c")
#- PB: nuestros códigos para los países están en "iso3c"

df_flags <- df %>% #- fips
  mutate(iso2 = countrycode(sourcevar = Country, 
                            origin = "iso3c", 
                            destination = "iso2c", warn = FALSE)) %>% 
  mutate(iso2 = tolower(iso2)) %>% 
  # glue:glue() : pega texto con "código", con objetos de R: los objetos tienen que ir entre corchetes {}
  mutate(flag_URL = glue::glue('https://hatscripts.github.io/circle-flags/flags/{iso2}.svg')) 

tt_flags <- df_flags %>% gt()
tt_flags #- lo mismo, solo se ven las rutas a las imagenes


tt_flags %>% 
  gt::text_transform(locations = cells_body(columns = c(flag_URL)), 
                     fn = function(x){gt::web_image(x, height = 30)})


#- pkg gtExtras: ---------------------------------------------------------------
#- pkg para añadir extra features a las tablas gt: https://jthomasmock.github.io/gtExtras/
#- trabajaremos con un df sencillito
df_ok <- df_flags %>% select( Country, flag_URL, W_medio, W_maximo, iso2)

#- cambiamos 2 enlaces
df_ok$flag_URL[3] <- "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Pirate_Flag_of_Jack_Rackham.svg/1280px-Pirate_Flag_of_Jack_Rackham.svg.png"

df_ok$flag_URL[1] <- "https://upload.wikimedia.org/wikipedia/commons/b/b8/Nacho_Vegas%2C_Roberto_Herreros_y_Christina_Rosenvinge_2014.JPG"

#- creamos la tabla
tt_ok <- df_ok %>% gt(rowname_col = c("Country")) 
tt_ok  

#- ponemos las banderas again (pero mas facil)
tt_ok <- tt_ok %>% gtExtras::gt_img_rows(flag_URL, height = 25)
tt_ok

#- un bar_plot con gtExtras::gt_plt_bar_pct()
tt_ok <- tt_ok %>% 
  gtExtras::gt_plt_bar_pct(column = W_maximo, scaled = FALSE, fill = "blue", background = "lightblue") %>%
  cols_align("center", contains("scale")) 
tt_ok

#- hay themes
tt_ok %>% gtExtras::gt_theme_nytimes() 
tt_ok %>% gtExtras::gt_theme_guardian()
tt_ok %>% gtExtras::gt_theme_espn()


#- gtExtras::gt_plt_dot()
tt_ok %>% 
  gtExtras::gt_plt_dot(column = W_medio, category_column = iso2,  max_value = 1993,
           palette = c("red", "pink", "purple", "blue")) %>% 
  gt::tab_header(title = "Salario medio y máximo por países")

#- se puede poner cualquier plot hecho con ggplot2
#- https://themockup.blog/posts/2022-06-13-gtextras-cran/#plotting-in-gt-with-gtextras

#- sparklines y más: https://themockup.blog/posts/2022-06-13-gtextras-cran/#gt_sparkline
data <- gapminder::gapminder %>% 
  filter(country %in% c("Spain", "France", "Argentina", "Iraq")) %>% 
  group_by(country) %>%
  # must end up with list of data for each row in the input dataframe
  summarize(lifeExp_list = list(lifeExp))
  
gt(data)

gt(data) %>% gtExtras::gt_plt_sparkline(lifeExp_list)
#- si queremos quitar los puntitos, excepto el ultimo
#- puede haber 5 colores: el primero la linea, el segundo el final, tercero es el valor más bajo ...
gt(data) %>% 
  gtExtras::gt_plt_sparkline(lifeExp_list, 
          palette = c("steelblue", "black", "red", "green", rep("transparent", 1)))


#- además, ggplot2, bueno, en realidad el pkg ggimage tb tiene ggimage::geom_image()
#- y vamos a hacer la foto redondita
#- un pkg para hacer imagenes circulares: https://twitter.com/danoehm/status/1588117821510516736
#- devtools::install_github("doehm/cropcircles")
url_a_img <- "https://upload.wikimedia.org/wikipedia/commons/e/e3/Coat_types_3.jpg"
my_foto_a <- cropcircles::circle_crop(url_a_img)

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() +
  ggimage::geom_image(aes(x = 7, y = 2, image = my_foto_a), size = 0.3)


#- Bueno ... y si supiésemos Observable: https://observablehq.com/@observablehq/summary-table


#- Bueno ... y datxray: https://github.com/agstn/dataxray
library(dataxray)
palmerpenguins::penguins %>% make_xray() %>% view_xray()
