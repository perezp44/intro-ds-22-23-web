#-  ej gt con gapminder
#- https://gt.albert-rapp.de/

library(tidyverse)
library(gt)
df <- gapminder::gapminder |> 
  janitor::clean_names() |> 
  select(continent, country, year, life_exp) |> 
  mutate(year = as.character(year)) # Year is really categorical with numeric labels
str(df)

library(gtExtras)
gtExtras::gt_plt_summary(df) 
