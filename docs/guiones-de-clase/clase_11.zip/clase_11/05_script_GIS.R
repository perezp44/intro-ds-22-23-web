#- script para seguir el tutorial_09 (GIS en R)
#- cargando pkgs 
options(scipen = 999) #- para quitar la notación científica
pacman::p_load(knitr, here, tidyverse, patchwork, ggrepel)
pacman::p_load(sf, rnaturalearth, rnaturalearthdata, ggspatial, mapview, leafem, leaflet, tmap)

#- si queréis hacer un mapa del mundo
library(tmap)
data(World)
class(World) #- es un sf, pero tb es un data.frame
names(World) #- fijate que la ultima columna se llama geometry y almacena los datos espaciales



#- fijate q el código de los paises esta en iso3c
world_geo <- World %>% select(iso_a3, name, continent, life_exp, geometry)
head(world_geo, n = 4)


#- si vuestro df no tiene los códigos de los paises o los tiene en otro formato, 
#- entonces hay que usar countrycode::countrycode()
#- https://www.jordimas.cat/courses/fiiei_es/introduccion/fuentes_indicadores_es_countrycode/

#- si necesitamos los codifos en iso2c
world_geo <- world_geo %>%  
  mutate(iso2c = countrycode::countrycode(iso_a3, 
                                          origin = "iso3c", 
                                          destination = "iso2c"), .after = iso_a3) 
#- si necesitamos los nombres en castellano
world_geo <- world_geo %>% 
  mutate(name_esp = countrycode::countrycode(iso_a3, 
                                             origin = "iso3c", 
                                             destination = "cldr.name.es"), .after = iso_a3) 

#- si necesitamos el continente ...
world_geo <- world_geo %>% 
  mutate(Continente = countrycode::countrycode(iso_a3, 
                                              origin = "iso3c", 
                                              destination = "continent"), .after = iso_a3) 
head(world_geo)


#- Ok, hagamos algún plot con world_geo
class(world_geo)
plot(world_geo, max.plot = 1)

#- quitar Antartida
my_fuera <- c("Territorios Australes Franceses", "Antártida")
world_geo <- world_geo %>% filter(  !(name_esp %in% my_fuera)  )
plot(world_geo, max.plot = 1)

#- la columna "geometry" es sticky ...  y suele ser pesada, cuesta visualizarla
zz <- world_geo %>% sf::st_drop_geometry()

str(world_geo)

#- podemos hacer mapas con ggplot: con geom_sf()
p1 <- ggplot(world_geo,  aes(fill = continent)) + 
          geom_sf() +
          #cale_fill_viridis_d(guide = "none") +
          labs(title = "Coord. geográficas")

p1


#--------- datos españoles
# load(here::here("datos", "geometrias_BigData_2021.RData"))



#- theme un poco más adecuado para mapas ---------------------------------------
theme_set(theme_bw())  
theme_set(cowplot::theme_map())


#- 3 formas equivalentes de usar geom_sf() (ya lo sabemos)
ggplot(data = world_geo) + geom_sf()
ggplot(data = world_geo, aes(geometry = geometry)) + geom_sf()
ggplot() + geom_sf(data = world_geo, aes(geometry = geometry))



#- mejoramos un poco el mapa
ggplot(data = world_geo) + 
  geom_sf(color = "black", fill = "lightgreen", lwd = 0.2)


#-
p1 <- ggplot(data = world_geo) + geom_sf() +
  labs(title = "Gráfico 1: Mapa del mundo",
       caption = "Datos provenientes de tmap")
p1


#- podemos jugar con las escalas de color
p1 + geom_sf(aes(fill = life_exp))
p1 + geom_sf(aes(fill = life_exp)) + scale_fill_distiller()
p1 + geom_sf(aes(fill = life_exp)) + scale_fill_viridis_c(option = "plasma")




#- proyecciones  ----
#- world2 <- st_transform(world, "+proj=laea +y_0=0 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs")
p1 + coord_sf(crs = "+proj=laea +y_0=00 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs") + 
  labs(subtitle = "Lambert Azimuthal Equal Area projection")

#- se pueden usar distintos sistemas para las proyecciones
p1 + coord_sf(crs = "+proj=laea +lat_0=52 +lon_0=10 +x_0=4321000 +y_0=3210000 +ellps=GRS80 +units=m +no_defs ")  #- usamos PROJ string

p1 + coord_sf(crs = st_crs(3035))  + #- usamos SRID identifier
  labs(subtitle = "(European-centric ETRS89 \nLambert Azimuthal Equal-Area projection)")




#- puntos. Centroides
world_points <- st_centroid(world_geo, of_largest_polygon = TRUE)    #- sustituye la geometry por el centroide
str(world_points)

p_points <- ggplot(data = world_points) + geom_sf(aes(color = continent)) + 
  labs(title = "Gráfico 1: Mapa del mundo (centroides)",
       caption = "Datos provenientes de tmap")

p_points + theme(legend.position = "none")

rm(p_points)

#- truqillo: ahora el centroide pasa a estar en 2 columnas, llamadas X e Y, donde figuran la longitud y latitud del centroide (luego lo usaremos!!)
world_points <- cbind(world_geo, st_coordinates(st_centroid(world_geo$geometry, of_largest_polygon = TRUE)))
names(world_points)



#- hagamos zoom en Spain
p1
p_esp <- p1 + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)
p_esp




#- ponemos en el centroide el nombre del país
p_esp + 
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
  annotate(geom = "text", x = 5.5, y = 38, 
           label = "Mar Mediterráneo", fontface = "italic", color = "red", size = 4)

#- en lugar del nombre, ponemos el valor de life_exp
p_esp + 
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = life_exp), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
  annotate(geom = "text", x = 5.5, y = 38, 
           label = "Mar Mediterráneo", fontface = "italic", color = "red", size = 4)


#- volvemos al mundo
p <- p1 + 
  geom_sf(fill = "antiquewhite") +
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
            color = "darkblue", fontface = "bold", 
            check_overlap = TRUE, size = 2) +
  annotation_north_arrow(location = "bl", which_north = "true",
                         pad_x = unit(0.75, "in"), 
                         pad_y = unit(0.5, "in"),
                         style = north_arrow_fancy_orienteering) +
  #theme(panel.grid.major = element_line(color = gray(.5), linetype = "dashed", size = 0.5)) +
  theme(panel.grid.major = element_blank()) +
  theme(panel.background = element_rect(fill = "aliceblue"))
p


#- volvemos a hecr zoom  en España
p + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE) +
  ggspatial::annotation_scale(location = "bl", width_hint = 0.5)


#-
## ggsave("./pruebas/map.pdf")
## ggsave("./pruebas/map_web.png", width = 6, height = 6, dpi = "screen")


#- vamos a crear un df con long y latitud de 2 "ciudades"
pueblos <- data.frame(
  nombre = c("Pancrudo", "Valencia"), 
  longitude = c(-1.028781, -0.3756572),
  latitude = c(40.76175, 39.47534) )     
pueblos


#- podemos poner esos puntos en nuestro mapa
p_esp + 
  geom_point(data = pueblos, 
             aes(x = longitude, y = latitude), 
             size = 2, color = "darkred") +
  geom_text(data = pueblos, 
            aes(x = longitude, y = latitude, label = nombre), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5)


#- si quisieramos pasar long y lat a sf
pueblos_sf <- st_as_sf(pueblos, 
                       coords = c("longitude", "latitude"), 
                       crs = 4326,  #- EPSG:4326 Coordenadas Geográficas WGS84
                       agr = "constant")

str(pueblos_sf)

#- al añadir una nueva capa con un df_sf se quita el zoom
p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred")


#- otra vez hacemos zoom
p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred") + 
  coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)


#- cargamos geometrías provinciales ----------------
prov <- pjpv.curso.R.2022::LAU2_prov_2020_canarias
plot(prov, max.plot = 1)

#- ponemos las geometrias de las provincias en nuestro plot (p)
p + geom_sf(data = prov, fill = "red") + 
  coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)


#- mapas interactivos --------------------------


#- mapas interactivos con tmap
library(tmap)
data(World)
names(World)

# coropletas con qtm()
qtm(World, fill = "life_exp")
qtm(World, fill = "life_exp", format = "World", style = "col_blind", projection = "+proj=eck4")


# coropletas con más opciones
qtm(World, fill = "life_exp", fill.n = 4, fill.palette = "div",
    fill.title = "Esperanza de vida",  style = "gray")


#- en realidad el pkg tmap tiene otra API
#- qtm() es para hacer quick graphs. 
#- Generalmente se usa está sintaxis con tmap

tmap_mode("plot")
tm_shape(World) + tm_polygons("life_exp",  n = 2) + tm_layout(bg.color = "skyblue")


tmap_mode("view")
tm_shape(World) + tm_polygons("life_exp", id = "name", popup.vars = TRUE)



tmap_mode("view")
data("World")     # ya lo habíamos hecho

tm_shape(World, projection = "+proj=eck4") +
  tm_polygons("HPI", n = 9, palette = "div", title = "Happy Planet Index", id = "name") +
  tm_style("gray") +
  tm_format("World")


#- con tmap se pueden hacer gráficos interactivos
tmap_mode("view")  


# dot map
data(metro)
head(metro)
qtm(metro, bbox = "China")

# without arguments, a plain interactive map is shown (si the mode is set to view)
qtm()

# search query for OpenStreetMap nominatim
qtm("Valencia")


#- bubble map con qtm()
qtm(World, borders = NULL) + 
  qtm(metro, symbols.size = "pop2010", 
      symbols.title.size = "Metropolitan Areas", 
      symbols.id = "name",
      format = "World")

