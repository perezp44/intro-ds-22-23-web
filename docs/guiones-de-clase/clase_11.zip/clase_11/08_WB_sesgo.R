library(tidyverse)
library(wbstats)

gdp <- wb_search(pattern = "gender", field = "indicator", extra = TRUE)

#- https://data.worldbank.org/indicator/SE.ENR.PRIM.FM.ZS
#- School enrollment, primary (gross), gender parity index (GPI)
#- https://data.worldbank.org/indicator/SE.ENR.SECO.FM.ZS

escolarizacion <- wb_data(indicator = c("SE.ENR.PRIM.FM.ZS", "SE.ENR.SECO.FM.ZS", "SE.ENR.TERT.FM.ZS"))

escol1 <- escolarizacion %>% filter(country == "Spain"|country == "Morocco"|
                                      country == "United States"|
                                      country == "Venezuela, RB"|
                                      country == "China"|
                                      country == "Australia") %>% filter(date >= 2000)


#gráfico IPG primaria
prim <- escol1 %>% filter (indicatorID == "SE.ENR.PRIM.FM.ZS")

primgg <- ggplot(prim, aes(x = date, y = value, color =country)) + geom_point() 

primgg


#gráfico IPG secundaria
sec <- escol1 %>% filter (indicatorID == "SE.ENR.SECO.FM.ZS")

secgg <- ggplot(sec, aes(x = date, y = value, color =country)) + geom_point() 

secgg


#gráfico IPG terciaria
terc <- escol1 %>% filter (indicatorID == "SE.ENR.TERT.FM.ZS")

tercgg <- ggplot(terc, aes(x = date, y = value, color =country)) + geom_point() 

tercgg


#- gganimate
library(dplyr)
library(gganimate)

library(wbstats)

gender <- wbsearch(pattern = "work", field = "indicator")
indicatorID <- wb(indicator = c("SL.TLF.ADVN.FE.ZS"))
advanzedu <- indicatorID %>% filter(country == "Spain")

graf <- ggplot(advanzedu, aes(x = date, y = value, group = indicator)) + 
        geom_line() + geom_point() +
        transition_reveal(date)

graf #- no funciona (pero hay q leer el error)

str(advanzedu)

advanzedu <- advanzedu %>% mutate(date = as.numeric(date))

graf <- ggplot(advanzedu, aes(x = date, y = value, group = indicator)) + 
        geom_line() + geom_point() +
        transition_reveal(date)
graf



#- HAY QUE mirar los ejemplos de la documentación
anim <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_line() +
  transition_reveal(Day)
anim


#- y "desmenuzar" los ejemplos
#- por ejmeplo hay que ver las vv. originales del df "airquality"
aa <- airquality