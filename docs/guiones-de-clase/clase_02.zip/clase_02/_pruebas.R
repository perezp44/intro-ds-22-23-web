#- script (o fichero .R) para pruebas ------------------------------------------
