library(tidyverse)
library(leaflet)
library(tidygeocoder)
library(leafpop)



#- geolocalizamos el SFPIE, con el pkg tidygeocoder ----------------------------
df <- data.frame(adress = "Servei de Formacio Permanent", 
                 street = "Serpis 29", 
                 city = "Valencia", 
                 country = "Spain")

df <- df %>% mutate(text_to_geocode = paste(street, city, country, sep = ", "))

df <- df %>% tidygeocoder::geocode(text_to_geocode, method = "osm")




#- hacemos un mapa con el paquete leaflet --------------------------------------
map <- leaflet() %>%
       addTiles() %>% 
       setView(lng = df$long, lat = df$lat, zoom = 16) 
map


#- añadimos markers al mapa
map <- map %>% 
       addMarkers(lng = df$long, lat = df$lat, popup = "SFPIE") %>% 
       addPopups(lng = df$long, lat = df$lat, popup = "SFPIE") 
map


#- vamos a ponerle una imagen al mapa ------------------------------------------
img <-  "https://www.uv.es/recursos/fatwirepub/ccurl/12/318/P01.jpg"
img <-  "./imagenes/R-logo.png"


map2 <- map %>% 
  addCircleMarkers(lng = df$long, lat = df$lat, group = "pnt") %>%
  addPopupImages(img, group = "pnt")


map2

#- se pueden poner muuuchos más elementos: https://rstudio.github.io/leaflet/basemaps.html
#- hay muchos "providers": http://leaflet-extras.github.io/leaflet-providers/preview/
map2 %>% addProviderTiles(providers$Stamen.Toner)
map2 %>% addProviderTiles(providers$Stamen.Terrain)
map2 %>% addProviderTiles(providers$Esri.NatGeoWorldMap)



map2 %>% addProviderTiles(providers$MtbMap) #- carril bici
  
