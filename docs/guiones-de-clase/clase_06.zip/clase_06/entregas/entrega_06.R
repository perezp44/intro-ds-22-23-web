#- ENTREGA nº 06 
#---- Pon tus datos de identificación ----------------------------
#- Apellidos: 
#- Nombre: 
#- e-mail: 
#- NPA: 
#-------------------------------------------------------------------------------
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
#-------------------------------------------------------------------------------
#- Solo has de subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, no hay que subir el Rproject, hay que subir solo el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_05_perez_pedro_GG445566.R
#-------------------------------------------------------------------------------

#- Objetivo: trabajar un poco más manejo de datos con dplyr, y en concreto algunas funciones como ifelse(), case_when(), is.na(), complete.cases() , entre otras
#- trabajaremos con datos de premios Nobel del proyecto "Tidy Tuesday"
#- los datos se pueden ver aquí: https://github.com/rfordatascience/tidytuesday/tree/master/data/2019/2019-05-14
#- para descargarlos hay que usar esta dirección: https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv

#- descarga los datos en "./datos/nobel_winners.csv"
el_url <- "https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv"
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
download.file(el_url, archivo_de_destino)

#- para importar los datos a R. Podríamos hacerlo con rio::import(), 
#- pero lo voy a hacer con readr::read_csv()
#- nos mostrará como se lee/interpreta cada columna (si es character etc...)
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
df_original <- readr::read_csv(archivo_de_destino)

#- ya tenemos los datos en el data.frame "df" trabajaremos sobre df para contestar una serie de preguntas y practicar con dplyr
rm(archivo_de_destino, el_url) #- borro lo q no nos hace falta

#- cargamos paquetes ------
library(tidyverse)

#- para visualizar mejor los datos voy a dejar solo 7 columnas
df <- df_original %>% 
      select(birth_country, laureate_type, prize_year, birth_date, category, gender, full_name)


#- Pregunta 0) ------------------------------------------------------------------ 
# Se trata de que expliques que hacen las siguientes lineas de código. 
#- Para ello tienes que escribir debajo de cada instrucción un comentario explicando lo que hace la instrucción de arriba. 
#- En todos los comentarios pon el nº de filas de aa.
#- Yo comento la primera instrucción para q te sirva de ejemplo

aa <- df %>% filter(birth_country == "Spain")  
#- seleccionamos las filas de los Nobeles ganados por españoles (aa tiene  7 filas). España solo ha ganado 7 Nobeles 6 de ellos en literatura) (Este comentario ya está hecho)

aa <- df %>% filter(birth_country != "Spain")  
#- pon aquí tu comentario. trata de entender xq no salen (969-7) filas, sino bastantes menos, concretamente 936


aa <- df %>% filter(birth_country != "Spain" | is.na(birth_country))  
#- pon aquí tu comentario. Fíjate que ahora sí salen (969-7)


aa <- df %>% filter(!(birth_country %in% c("Spain")) ) 
#- pon aquí tu comentario. Fíjate que ahora tb (969-7)




#- Tampoco le des muchas-muchas vueltas, hay que hacerlo en menos de 3 horas (lo siento!!). La intención del ejercicio es que trabajases un poco con el operador ! , y que vieses que los operadores "==" e  %in% no son exactamente iguales. la conclusión final es que cuando en tu df hay NA's hay que extremar las precauciones al seleccionar los casos/filas



#- Pregunta 1) ----------------------------------------------------------------- 
#- Muestra los 5 países con más Nobeles  
#- Puedes usar n() o count() o ...


#- Pregunta 2) -----------------------------------------------------------------
#- seleccionar los 26 premios Nobel de los que no sabemos el país de nacimiento. 
#- Pista: is.na()



#- Pregunta 3) -----------------------------------------------------------------
#- Seleccionar los premios Nobel de los que SÍ sabemos el país de nacimiento. 
#- Pista: !!!!!!




#- Pregunta 4) -----------------------------------------------------------------
#- Has de filtrar los casos completos; es decir, dejar solo las filas que no tienen ningún NA. 
#- Pista: usa la función tidyr::drop_na(). Igual tenéis que mirar la documentación de la función. Los ejemplos suelen ser bastante ilustrativos





#- Pregunta 5) -----------------------------------------------------------------
#- Para aquellos premios Nobel que no sabemos donde han nacido, suponemos y ponemos que han nacido en "Marte". 
#- Pista: ifelse()


#- Pregunta 6) -----------------------------------------------------------------
#- Tenéis que crear una nueva variable llamada "my_comentario". Si el Nobel ha nacido en "Spain" ponemos "Olé!!". Si ha nacido en Francia ponemos "Très bien", y si ha nacido en "United States of America" ponemos "Wikidata mola". Para los de los demás países ponemos "NV Nobel ya!!"
#- Pista: la función que tenéis que usar es case_when(). Mira un ejemplo de ayuda y cópialo para empezar



#- Pregunta 7) -----------------------------------------------------------------
#- Cuantos premios Nobel ha habido cada año:



#- Pregunta 8) -----------------------------------------------------------------
#- Encontrar el año en el que un sólo país se ha llevado el mayor porcentaje de premios Nobel
#- Pista: hay q agrupar con group_by() 2 veces



#- Pregunta 9) -----------------------------------------------------------------
#- Encuentra el Nobel más viejo y el más joven
#- Venga, esta vez os ayudo: yo calculo la edad a la que recibieron el premio
str(df) #- la v "birth_date" es de tipo Date (fecha)

library(lubridate) #- para trabajar con fechas el paquete lubridate
aa <- df %>% 
  mutate(anyo_nac = lubridate::year(birth_date)) %>%
  mutate(edad = prize_year- anyo_nac) %>%
  select(prize_year, category, full_name, birth_country, birth_date, edad)




#- Pregunta 10) -------------------------------------------------------------------------
#- Calcula la edad media por categoría
#- Warning: cuidado con los Na's al calcular la media



#- Pregunta 11) -------------------------------------------------------------------------
#- calcula la categoría en la que han ganado más porcentaje de mujeres. 



#- Pregunta 12) ----------------------------------------------------------------
#- Vamos a fusionar dos tablas, dos df's. Por favor fusiona df con gapminder. 
#- Os ayudo:
#- Antes limpiamos el Global Env.
objetos_no_borrar <- c("df")
rm(list = ls()[!ls() %in% objetos_no_borrar])

#- cargamos gapminder en memoria. 
gapminder <- gapminder::gapminder 

#- simplificamos gapminder: dejamos solo 3 columnas de gapminder y solo el año 2007
gapminder <- gapminder %>% select(1, 3, 4) %>% filter(year == 2007)

#- simplifico df: dejo solo el año 2007 y quitamos alguna columna para que todo se vea mejor
df <- df %>% filter(prize_year == "2007") %>% select(- c(laureate_type, birth_date))

#- Tu TAREA: ---
#- vamos a fusionar df y gapminder la variable para poder fusionar es el nombre del país.
#- En df el nombre del país está en la columna "birth_country" y en gapminder el país está en la v. "country"
#- se pueden hacer distintos tipos de fusiones. veamos 3: left, inner y full




#- Pregunta 13) ----------------------------------------------------------------
#- Para acabar la entrega_06, tienes que hacer un gráfico. Da igual si es de premios Nobel o no. 
#- Podéis fusilar/copiar uno de esta galería: https://www.r-graph-gallery.com/
#- pero eso sí, explica con palabras que tipo de gráfico es y que variables y geom_xx estás usando







#- Si quieres hacer un gráfico con n los datos de los Nóbeles, aquí tienes algunos:
#- https://twitter.com/hashtag/tidytuesday
#- https://twitter.com/PBecciu/status/1128345721634197505
#- https://twitter.com/CapandChange/status/1128380077690032128
#- https://twitter.com/jon_cole/status/1128326024792383488
#- https://twitter.com/FiskerBang/status/1128198912827895808
#- https://twitter.com/IamMRWani/status/1128190807620481024
#- https://twitter.com/dataknut/status/1128164352308072449
#- https://twitter.com/geokaramanis/status/1128391346597847040
#- https://twitter.com/oranwutan/status/1128643059116322817/photo/1   (el de las funciones de David Robinson)

#- generalmente David Robinson hace un screencast: https://www.youtube.com/channel/UCeiiqmVK07qhY-wvg3IZiZQ

#- ademas en Kaggle ya hubo una competición con estos datos: https://www.kaggle.com/nobelfoundation/nobel-laureates
#- aqui tienes dos ejemplos
# https://nbviewer.jupyter.org/github/shantel-martinez/shantel-martinez.github.io/blob/master/Rmd%20Protocols/TidyTuesdayWk20.html
# https://dataknut.github.io/tidytuesday/2019-05-14.html




