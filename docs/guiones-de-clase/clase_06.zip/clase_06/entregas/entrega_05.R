#- ENTREGA nº 05 
#---- Pon tus datos de identificación ----------------------------
#- Apellidos: 
#- Nombre: 
#- e-mail: 
#- NPA: 
#-------------------------------------------------------------------------------
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
#-------------------------------------------------------------------------------
#- Solo has de subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, no hay que subir el Rproject, hay que subir solo el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_05_perez_pedro_GG445566.R
#-------------------------------------------------------------------------------


#- Objetivo: trabajar unos datos con dplyr para entender sus funciones y aprender a manejar datos con R
#- trabajaremos con datos de población de los municipios españoles extraídos del Padrón del INE
#- los datos están en: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda

#- lo primero es descargar los datos en la carpeta "./pruebas/"


#- importamos los datos a R (al Global env.)

#- ya podemos trabajar con ellos. ya están en la memoria de R 
#- tenemos los datos en el data.frame "df" trabajaremos sobre df para contestar una serie de preguntas y practicar con dplyr
#- cargamos paquetes que vamos a necesitar


#- antes de hacer nada con unos datos conviene saber un poco que son y su estructura (análisis preliminar)
#- vemos los datos: el df tiene 13 columnas/variables. 
#- Como vemos son datos de población total, hombre y mujeres en los municipios españoles para varios años, de 1996 a 2020
#- con str() vemos la estructura de df:  
str(df)   

#- las 2 primeras columnas parecen númericas pero son de tipo character, 
#- la tercera (year) es numerica 
#- más adelante veremos mas cosas que hay que hacer con un df antes de empezar a trabajar con ellos
#- ahorano podemos detenernos, hay que avanzar para tener conocimientos (auqnue sea con pinzas) de todo las etapas del proceso


#- TAREA ZERO: (ya está resuelta)
#- ¿Cuantos habitantes había en 2015 en el municipio con nombre "Pancrudo"?




#- Pregunta 1) -----------------------------------------------------------------
#- Muestra en un data.frame llamado aa los habitantes que tenía tu municipio de nacimiento en los distintos años. 
#- Para aquellos que han nacido fuera de España, vuestro municipio es "Cariño", un municipio de la provincia de "Coruña, A"
# Nota: Identificar por nombre siempre es problemático, piensa que el nombre puede estar escrito en castellano o valenciano, inglés, o simplemente mal escrito, o abreviado etc.... 
#- Siempre que sea posible es mejor identificar por código; por ejemplo, para identificar a los estudiantes es mejor el NPA, porque es único, mientras que Pedros puede haber muchos.
# Otra nota: Para identificar de manera única un municipio español son necesarios 2 códigos: el código del municipio y el código de la provincia. En nuestros datos estos dos códigos están juntos en la variable ine_muni. Por ejemplo el municipio de Pancrudo en la provincia de Teruel se identifica de forma única con ine_muni = "44177". Los 2 primeros números corresponden al código provincial: la provincia de Teruel tiene el código 44.
#- Piensa que a lo mejor, tu pueblo no se puede identificar por nombre. Esto pasaría si hubiese otro municipio que se llame igual


#- Pregunta 2) -----------------------------------------------------------------
#- ¿Cuantas provincias diferentes hay en España si las identificamos con la v. ine_prov? (se puede responder a esta pregunta de muuuuuchas formas, incluso preguntándoselo a Alexa o ala Wikipedia y evmos q hay 52 "provincias"


#- Pregunta 3) -----------------------------------------------------------------
#- muestra las 5 CC.AA que en 2017 tenían más habitantes
#- Nota: al final tendréis que usar la f. slice() pero antes justo antes de usar slice() tendréis que hacer ungroup()
#- también podéis no hacerme caso y tratar de usar slice_max()


#- Pregunta 4) -----------------------------------------------------------------
#- En 2017, muestre las 10 provincias con mayor número de municipios. 
#- Que se vea tanto el el nombre de la provincia como su código






#- Pregunta 5)
#- En 2020, ¿cuantos municipios tenían exactamente el mismo número de mujeres que de hombres?



#- Pregunta 6)
#- Calcula el número de municipios que han habido cada año en España
# Comment: sí, el nº de municipios cambia año a año porque algunos se juntan, otros se separan, ...



#- Pregunta 7) -----------------------------------------------------------------
#- En 2020, ¿cuantos municipios habían con el mismo nombre?






#- Pregunta 8) -----------------------------------------------------------------
#- ¿Qué municipio ha visto crecer mas su número de habitantes desde 2000? En esta pregunta, no os hace falta, pero os voy a ayudar un poco, yo lo voy a hacer para mi pueblo, vosotros solo tendréis que modificar el código para que lo haga para todos los municipios
#- es muy parecido a lo q hicimos en clase

#- Solución, pero solo para Pancrudo ()
df_pancrudo <- df %>% 
  select(year, ine_muni, ine_muni.n, ine_prov.n, pob_total) %>% #- me quedo con 5 variables
  filter(ine_muni.n == "Pancrudo") 

aa <- df_pancrudo %>% filter(year %in% 2000:2020) %>% 
  group_by(ine_muni) %>%  #- no hace falta
  arrange(year) %>% 
  mutate(crec_pob_1_anyo = pob_total - lag(pob_total)) %>%
  mutate(crec_pob_desde_2000 = pob_total - first(pob_total)) %>%
  mutate(crec_pob_desde_2000_percent = crec_pob_desde_2000 / first(pob_total) *100) %>% 
  mutate(crec_pob_desde_2000_percent = round(crec_pob_desde_2000_percent, digits = 2))


#- ahora ya lo tenéis que hacer vosotros para todos los municipios
#- solo hay que hacer un group_by() por municipio


#- Pregunta 9) -----------------------------------------------------------------
#- ¿Que municipio ha visto crecer mas, en porcentaje, su población de mujeres desde 2010?
#- podéis reusar el código de  la pregunta anterior. Simplemente tendréis que sustituir algunas cosas: Pob_T por Pob_M  y 2010 por 2000


#- Pregunta 10) ----------------------------------------------------------------
#- Muestre como ha evolucionado la diferencia de población entre Madrid y Barcelona a lo largo del tiempo
#- se puede hacer de varias formas pero en este caso prefiero aprovechar la pregunta para practicar con pivot_wider()
#- como quiero que resolváis la pregunta de una determinada manera, os hago yo los primeros pasos



#- ULTIMA TAREA:
#- borra (usando código) todos los archivos que haya en la carpeta "./datos/pruebas/"
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)  
fs::file_delete(lista_de_archivos)

my_carpeta <- "./datos/pruebas"   #- con R-base (por si no tenéis instalado el paquete "fs")
lista_de_archivos <- list.files(my_carpeta, full.names = TRUE)
file.remove(lista_de_archivos)


