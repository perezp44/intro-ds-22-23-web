#- script para seguir las slides_05 sobre fusionado de tablas

library(tidyverse)

#- COMBINANDO df's -------------------------------------------------------------
#- COMBINANDO df's -------------------------------------------------------------

#- slide nº 47 -----------------------------------------------------------------
#- 2 df's con las mismas filas
df_1 <- iris[ , 1:2]           ; df_2 <- iris[ , 3:5]
df_1 <- iris %>% select(1:2)   ; df_2 <- iris %>% select(3:5) 

df_3 <- bind_cols(df_1, df_2)
identical(iris, df_3)

#- 2 df's con las mismas columnas
df_1 <- iris[1:75, ]          ; df_2 <- iris[76:150, ]
df_1 <- iris %>% slice(1:75)  ; df_2 <- iris %>% slice(76:150)

df_3 <- bind_rows(df_1, df_2)
identical(iris, df_3)


#- Mutating joins --------------------------------------------------------------
#- slide nº 49 -----------------------------------------------------------------
#- Para los ejemplos de joins usaremos estos df's
x <- tibble(id = 1:3, x = paste0("x", 1:3))
y <- tibble(id = (1:4)[-3], y = paste0("y", (1:4)[-3]))


#- slide nº 50 -----------------------------------------------------------------
