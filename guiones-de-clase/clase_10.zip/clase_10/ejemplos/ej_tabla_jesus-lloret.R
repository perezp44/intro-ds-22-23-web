#- trabajo individual de Jesús Lloret: https://jelloque.github.io/trabajo_BigData/
#- aqui tenéis el post del q posiblemente sacó el código para la tabla. En el post hacen una tabla más compleja: https://bjnnowak.netlify.app/2021/10/04/r-beautiful-tables-with-gt-and-gtextras/

library(tidyverse)
library(scales)
library(gt)
library(tidytuesdayR) #- install



#- datos
#- tuesdata <- tidytuesdayR::tt_load('2020-04-07')
tuesdata <- tidytuesdayR::tt_load(2020, week = 15)


tdf_winners <- tuesdata$tdf_winners
stage_data <- tuesdata$stage_data
tdf_stages <- tuesdata$tdf_stages
rm(tuesdata)
str(tdf_winners)
#str(stage_data)
#str(tdf_stages)



#- tabla ---------------
#Tabla 1 corredores mas laureados
#Realmente esta tabla no tiene mucho merito porque ha sido reproducir literalmente el codigo de un usuario por internet pero me ha parecido tan bonita y elegante que me he visto casi forzado a ponerla...

most_wins<-tdf_winners%>%
  # Lo primero es borrar a Armstrong por tramposo
  filter(winner_name!="Lance Armstrong")%>%
  mutate(winner_name=case_when(
    winner_name=='Miguel Induráin'~'Miguel Indurain',
    TRUE~winner_name
  ))%>%
  # Crear la variable para contar titulos
  mutate(ct=1)%>%
  group_by(winner_name)%>%
  summarize(
    # Contamos Titulos
    Titulos=sum(ct),
    # Añadimos nacionalidad
    Nacionalidad=nationality[1],
    # Añadimos el apodo
    Nickname=nickname[1])%>%
  filter(Titulos>2)%>%
  arrange(-Titulos)

# Data preparation:
most_wins<-most_wins%>%
  #  ordenando las columna
  select(
    Corredor=winner_name,
    Nickname,Nacionalidad,Titulos)%>%
  # Limpiando los apodos
  mutate(Nickname=case_when(
    str_detect(Corredor,'Hinault')~'The Badger',
    str_detect(Corredor,'Anquetil')~'Maître Jacques',
    str_detect(Corredor,'Indurain')~'Miguelón',
    str_detect(Corredor,'LeMond')~"The American",
    str_detect(Corredor,'Bobet')~'Zonzon',
    str_detect(Corredor,'Thys')~'The Basset Hound',
    TRUE~Nickname
  ))

most_wins <- most_wins%>%
  mutate(Nacionalidad = case_when(
    str_detect(Nacionalidad,'France') ~ 'https://raw.githubusercontent.com/BjnNowak/TdF/main/fr.png',
    str_detect(Nacionalidad,'Belgium') ~ 'https://raw.githubusercontent.com/BjnNowak/TdF/main/be.png',
    str_detect(Nacionalidad,'Great Britain') ~ 'https://raw.githubusercontent.com/BjnNowak/TdF/main/uk.png',
    str_detect(Nacionalidad,'Spain') ~ 'https://raw.githubusercontent.com/BjnNowak/TdF/main/sp.png',
    str_detect(Nacionalidad,'United States') ~ 'https://raw.githubusercontent.com/BjnNowak/TdF/main/us.png'
  ))

tabla <- most_wins%>%
  gt()%>%
  tab_header(
    title = "Corredores con más victorias en el Tour de Francia"
  )%>%
  gtExtras::gt_theme_nytimes()%>%
  gtExtras::gt_merge_stack(col1 = Corredor, col2 = Nickname)%>%
  # añadimos las banderas
  gtExtras::gt_img_rows(columns = Nacionalidad, height = 20)


#- arriba la tabla ya está chula, PERO le ñade unos iconos de fontawesome::fa()
fontawesome::fa(name = "r-project", fill = "steelblue")
fontawesome::fa(name = "download", fill = "steelblue")
fontawesome::fa(name = "mug-hot", fill = "steelblue")

tabla%>%
  gtExtras::gt_fa_repeats(
    column=Titulos,
    palette = "orange",
    name = "tshirt",
    align='left'
  )


#- con el ejemplo de la función  entendéis gtExtras::gt_fa_repeats() -----------
library(gt)
fa_cars <- mtcars[1:8,1:4] %>% gt()
fa_cars


fa_cars.b <- fa_cars %>%
  gtExtras::gt_fa_repeats(cyl, name = "car")
fa_cars.b

#- elegimos el color
fa_cars.b <- fa_cars %>%
  gtExtras::gt_fa_repeats(cyl, name = "car", palette = "green")
fa_cars.b


#- ponemos otro icono ("mug-hot")
fa_cars.b <- fa_cars %>%
  gtExtras::gt_fa_repeats(hp, name = "mug-hot")
fa_cars.b

#- pongamos nosotros los colores --
my_pal = c("#838383", "orange", "#00AA00") #- puede ser 1 color o los mimos que los valores únicos de la columna
scales::show_col(my_pal)

fa_cars.b <- mtcars[1:5,1:4] %>% gt() %>% 
  gtExtras::gt_fa_repeats(cyl, name = "car", palette = my_pal)
fa_cars.b



