#- script para procesar datos de la EPA
#- https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=ultiDatos&idp=1254735976595

library(tidyverse)
library(pxR) #- install.package("pxR")  
library(sf)  #- xq haremos algún mapa

#- hay datos en tablas y datos completos (los microdatos)


#- por ejemplo esta TABLA: https://www.ine.es/jaxiT3/Tabla.htm?t=4247&L=0
#- contiene las Tasas de paro por distintos grupos de edad, sexo y comunidad autónoma
#- Esta tabla se puede descargar en varios formatos. 
#- Por ejemplo los descargaremos en .csv, .xlsx y pcaxis
#- Estos son los enlaces:
#- https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1

#- en csv
#- salen decentes y en formato ancho
fs::dir_create("pruebas") #- primero creamos la carpeta "pruebas"
my_url <- "https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.csv")
df_csv <- rio::import("./pruebas/epa_tab_1.csv")

#- en xlsx ---------------------------------------------------------------------
#- bueno, no salen decentes, habría que arreglarlos
#- quizas para vosotros sea mejor arreglarlos en Excel (!!!!!)
my_url <- "https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.xlsx")
df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx")

#- se pueden arreglar, pero ....
# df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx", skip = 7)
#- habría q pasarlo a largo (y lo complica el hecho de que Total, H y M


#- en pcaxis -------------------------------------------------------------------
#- salen decentes y en formato ancho
library(pxR) #- install.package("pxR")

my_url <- "https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.px")
df_px <- pxR::read.px("./pruebas/epa_tab_1.px") %>% as.data.frame 


#- microdatos ------------------------------------------------------------------
#- es otra historia (algo diré en clase)

dicc <- rio::import("https://www.ine.es/ftp/microdatos/epa/dr_EPA_2021.xlsx")

#- Los microdatos se descargan en un fichero .zip con los datos en muchos formatos
#- abrimos ficheros en varios formatos -----------------------------------------
#- no funcionará xq no hemos bajado esos ficheros
# epa_sas <- haven::read_sas("tmp/SAS/epa_2020t3.sas7bdat", NULL)
# epa_spss <- haven::read_sav("tmp/SPSS/EPA_2020T3.sav")
# epa_stata <- haven::read_dta("tmp/STATA/EPA_2020T3.dta")
# epa_csv <- readr::read_delim("tmp/CSV/EPA_2020T3.csv", "\t", escape_double = FALSE, locale = locale(date_names = "es"), trim_ws = TRUE)



#- vamos a arreglar/usar una tabla ---------------------------------------------
rm(list= ls())


#- descargamos la tabla en formato .csv
df_csv <- rio::import("./pruebas/epa_tab_1.csv")
names(df_csv)

df <- janitor::clean_names(df_csv) 
names(df)

#- vemos q hay en la tabla
df_dicc <- pjpv.curso.R.2022::pjp_dicc(df)


#- renombro 1 v. y me quedo con los Totales (tanto en genero como en edad)
df <- df %>% 
  dplyr::rename(CCAA = comunidades_y_ciudades_autonomas) %>% 
  filter(sexo == "Ambos sexos") %>% 
  filter(edad == "Total") 
str(df)

#- la v. fecha está como texto ("2022T3") la pasamos a fecha
df <- df %>% 
  mutate(fecha = lubridate::yq(periodo)) 
str(df)
#- para ver como se almacenan realmente las fechas
zz <- df %>% mutate(fecha_x = unclass(fecha))
  
#- si queremos tener el año y el mes
df <- df %>% mutate(anyo = lubridate::year(fecha))
df <- df %>% mutate(mes = lubridate::month(fecha))
df <- df %>% mutate(trimestre = lubridate::quarter(fecha))



#- me quedo con los totales para ESP  ------------------------------------------
#- y hago un gráfico chapucero
df_esp <- df %>% 
  filter(CCAA == "Total Nacional") %>% 
  select(-c(edad, sexo))

ggplot(df_esp, aes(x = fecha, y = total, group = 1)) +
  geom_line() + geom_point() 


#- vamos a hacer ahora una coropleta con la tasa de paro de cada CA
df_ccaa <- df %>% 
  filter(CCAA != "Total Nacional") %>% 
  select(-c(edad, sexo))

df_ccaa <- df_ccaa %>% 
  tidyr::separate(CCAA, sep = " ", 
                  into = c("ine_ccaa", "ine_ccaa.n"), extra = "merge") 


  
#- cargo geometrías de CCAA
df_geo_prov <- pjpv.curso.R.2022::LAU2_prov_2020_canarias

#- podemos ver q la última columna de df_geo_prov tiene las "geometrías"
head(df_geo_prov)
df_geo_prov[1:5, c(1, 2, 11)]  #- x recordar algo de Rbase

pjpv.curso.R.2022::
#- de las provincias obtenemos los contornos de las CC.AA
df_geo_ccaa <- df_geo_prov %>% 
  group_by(ine_ccaa) %>% dplyr::summarize()


#- juntamos datos de la EPA con las geometrías
df_ok <- left_join(df_ccaa, df_geo_ccaa, by = c("ine_ccaa" = "ine_ccaa"))

#- me quedo solo con el último dato de la EPA
df_ok <- df_ok %>% filter(fecha == max(fecha))


#- basic plot
p <- ggplot() + 
  geom_sf(data = df_ok, 
          aes(geometry = geometry, fill = total), 
          color = "white", size = 0.09) 

p
names(df_ok)

#- mejoramos un poco el plot ---------------------------------------------------

#- para ello calculo centroides (!!!)
df_geo_ccaa <- cbind(df_geo_ccaa, st_coordinates(st_centroid(df_geo_ccaa$geometry)))

#- vuelvo a juntar datos EPA con geometrías (q ahora incorporan los centroides)
df_ok <- left_join(df_ccaa, df_geo_ccaa)

#- me quedo solo con el último dato de la EPA
df_ok <- df_ok %>% filter(fecha == max(fecha))

p <- ggplot() + 
  geom_sf(data = df_ok, 
          aes(geometry = geometry), fill = "antiquewhite", 
          color = "black", size = 0.09) +
  geom_text(data = df_ok, aes(x = X, y = Y, label = total), #- v. continua
            color = "black",  
            check_overlap = TRUE, size = 3)  #- fontface = "bold"

p

#- luego ya hay que tunearlo (un poco)
p + pjpv.curso.R.2022::theme_pjp_maps() +
  labs(title = "Tasa de desempleo (%)", 
       subtitle = "(datos de la EPA)", 
       caption = "@pjpv4444 • Datos provenientes del INE")

#- hasta dejarlo mas o menos PRO: https://perezp44.github.io/pjperez.web/01_blog.html

#- cartograma con tmap ---------------------------------------------------------
# remotes::install_github("r-tmap/tmaptools", force = TRUE)
# remotes::install_github("r-tmap/tmap", force = TRUE)
#- no me ha salido, no tenia temps (🥲)
library(tmap)
library(tmaptools)
library(sf)
data(World, rivers, metro) #- hacemos accesibles 3 conjuntos de datos (df's)

tm_shape(World) +
  tm_polygons("life_exp")


dff <- sf::st_sf(df_ok)
tm_shape(dff) +
  tm_polygons("total")
names(df_ok)

