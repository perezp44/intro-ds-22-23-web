#- ENTREGA nº 09
#---- Pon tus datos de identificación ------------------------------------------
#- Apellidos: 
#- Nombre: 
#- e-mail: 
#- NPA: 
#-------------------------------------------------------------------------------
#- Para entregar tus tareas, graba esta plantilla en un script (archivo .R)
#- Evidentemente, incorpora (en los huecos que hay) las soluciones a las tareas
#- No te olvides de rellenar los datos de identificación
#-------------------------------------------------------------------------------
#- Solo has de subir al uploader el fichero .R (solo el fichero .R, sin comprimir)
#- Repito, no hay que subir el Rproject, hay que subir solo el fichero .R (sin comprimir)
#- El fichero .R  se ha de llamar entrega_09_perez_pedro_GG445566.R
#-------------------------------------------------------------------------------


#- Objetivo: trabajar un poco más con ggplot2 ----------------------------------

#- Para ello, antes bajaremos datos del Banco Mundial con el paquete "wbstats": https://github.com/GIST-ORNL/wbstats
#-
library(tidyverse)   #install.packages("wbstats")
library(wbstats)
#- el pkg wbstats solo tiene una vignette: https://cran.r-project.org/web/packages/wbstats/vignettes/Using_the_wbstats_package.html
#- wbstats nos facilita ver que datos tiene el World Bank, porque tiene almacenada esa información en la lista "wb_cachelist"
lista_codigos <- wbstats::wb_cachelist #- nos traemos "wb_cachelist" al Global environment
str(lista_codigos, max.level = 1 )     #- vemos con str(), la estructra de la lista "lista_codigos"
#- veamos más en detalle que información tiene el World Bank
lista_countries  <- lista_codigos[[1]]  #- R-base:con el operador [[xx]] podemos seleccionar el elemento xx de la lista
lista_indicators <- lista_codigos[[2]]
lista_sources    <- lista_codigos[[3]]
lista_topics     <- lista_codigos[[4]]

#- aprovechamos este post: https://github.com/keithmcnulty/hans_rosling_bubble/blob/master/rosling.R
#- para bajarnos datos anuales (1960-2018) de todos los paises de 3 indicadores similares a los que tiene el pkg "gapminder":
#- SP.DYN.LE00.IN:	Life expectancy at birth, total (years)
#- NY.GDP.PCAP.CD:	GDP per capita (current US$)
#- SP.POP.TOTL   :	Population, total
#- bajamos los datos del World Bank con la f. wb() del pkg "wbstats"

datos <- wbstats::wb(indicator = c("SP.DYN.LE00.IN", "NY.GDP.PCAP.CD", "SP.POP.TOTL"), 
                          country = "countries_only", startdate = 1960, enddate = 2021) 

#- nueva API del pkg: 
#datos_x <- wbstats::wb_data(indicator = c("SP.DYN.LE00.IN", "NY.GDP.PCAP.CD", "SP.POP.TOTL"),                          country = "countries_only", start_date = 1960, end_date = 2021) 
#- los 3 indicadores en realidad deberían ir en columnas distintas porque sus valores están en unidades diferentes: años, dolares y personas; así que uso pivot_wider()
datos <- datos %>% select(-c(indicator)) #- antes quito la variable "indicator" que sobra y dificulta el trabajo
datos_wider <- datos %>% pivot_wider(names_from = indicatorID, values_from = value)

#- arreglo los nombres de los indicadores para que sean mas intuitivos
datos_wider <- datos_wider %>% rename(esperanza_vida = SP.DYN.LE00.IN) %>% 
                               rename(poblacion = SP.POP.TOTL) %>% 
                               rename(PIB_percapita = NY.GDP.PCAP.CD) 


#- como veis, si comparamos con los datos de gapminder, nos falta la variable continente. 
#- Tenemos una v. parecida a continent en el df lista_countries: concretamente tenemos la variable "region"
zz <- lista_countries %>% distinct(region) #- fijaros que el World Bank agrupa los paises en 8 regiones

#- vamos a añadir la region a  datos_wider ¿cómo? juntando las tablas con left_join() 
zz <- lista_countries %>%  select(iso3c, region, region_iso3c)
datos_juntos <- left_join(datos_wider, zz, by = c("iso3c" = "iso3c")) #- juntamos las 2 tablas


#- OK, finalmente vamos a trabajar con el data.frame datos_juntos, así que voy a borrar los demás objetos de la memoria de R
#- pero antes a datos_juntos "lo voy a llamar df" para trabajar mas cómodo:
df <- datos_juntos
rm(list = setdiff(ls(), "df"))   #- borra todos los objetos en el Global, excepto df


#- Como bajarse los datos de la web del World Bank cuesta un ratito, casi merece la pena guardar df por si acaso. Como siempre lo guardo en "./pruebas/" con el paquete rio
rio::export(df, "./pruebas/df_world_bank.rds")

#-
#- y así si tienes que retomar el análisis puedes hacerlo desde AQUÍ -
#-

#- COMIENZA la practica de GGPLOT2 ---------------------------------------------

library(tidyverse)
df <- rio::import(here::here("pruebas", "df_world_bank.rds"))  #- df tiene 12.773 rows x 9 columnas

#- vamos a trabajar SIEMPRE con los datos desde 1980 a 2020:
df <- df %>% mutate(date = as.numeric(date))  #- pasamos date (q es character) a numeric
df <- df %>% filter(date >= 1980)

#- veamos un poco los datos (tienes que ver de que tipo son (character o numeric, ...), si tienen NAs, sus valores únicos)
#- remotes::install_github("perezp44/pjpv2020.01")
df_aa <- pjpv2020.01::pjp_f_estadisticos_basicos(df)  #- estadísticos básicos del df
df_bb <- pjpv2020.01::pjp_f_valores_unicos(df)        #- valores únicos de cada variable de df


#- PREGUNTAS: ------------------------------------------------------------------


#- Pregunta 1) -----------------------------------------------------------------
#- muestra la evolución en el tiempo de la Esperanza de vida en "Spain" (atención: siempre con datos desde  1980). El eje y que empiece en 0.


p1 <- df %>% filter(country == "Spain") %>% 
       ggplot(aes(x = date, y = esperanza_vida)) +
          geom_point() + 
          geom_line()  
p1

#- para que el eje Y empiece en cero hay muchas formas de hacerlo

p1 +  ylim(c(0, NA))

p1 + scale_y_continuous(breaks = seq(0, 90, 10),  limits = c(0, 90))


#- fijaros q gráfico ha hecho Luis Pérez:
#- genial Luis ... pero no me separas el operador de asignación de los objetos 😀 
library(colorfindr)
library(patchwork)

my_url<-"https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Bandera_de_Espa%C3%B1a.svg/300px-Bandera_de_Espa%C3%B1a.svg.png"

img<-magick::image_read(my_url)

p <- df %>% filter(country=="Spain")%>% drop_na()%>% arrange((date))

data<- ggplot(p,aes(x=date , y=esperanza_vida))+
  geom_point(color="yellow")+
  coord_cartesian(ylim=c(0,NA)) +
  geom_line(color="red") +
  labs(
    title="Evolucion de la esperanza de vida en España",
    y="Esperanza de Vida"
  )


c<-ggplot()+ ggpubr::background_image(img)+coord_fixed()

c+data




#- Pregunta 2) -----------------------------------------------------------------
#- Muestra la evolución de la esperanza de vida (recuerda que siempre desde 1980) para los siguientes países:
#paises <- c("Spain", "France", "Germany", "Norway", "Belgium", "Portugal", "United States", "Argentina")

paises <- c("Spain", "France", "Italy", "Poland", "Germany", "Portugal", "United States", "Argentina")
df_paises <- df %>% filter(country %in% paises)

p2 <- ggplot(df_paises, aes(x = date, y = esperanza_vida, color = country)) +
       geom_point() + 
        geom_line()

p2

#- Pregunta 3) -----------------------------------------------------------------
#- Haz el mismo gráfico que hemos hecho antes pero que las lineas (y puntos) de todos los países se vean en gris, pero que la linea de España se vea en "orange"
#- Pista: en algún momento tendrás que hacer dentro de aes(...., group = country)

df_esp <- df %>% filter(country == "Spain")

#- fijate q uso   group = country (para que reconozca q hay distintos países)
p3 <- ggplot(df_paises, aes(x = date, y = esperanza_vida, group = country)) +
        geom_line(colour = "grey80") + 
        geom_line(data = df_esp, color = "orange") +
        geom_point(data = df_esp, color = "orange") 

p3
#- a veces alguien hace un pkg para hacer una operación concreta. Por ejemplo
library(gghighlight) #- install.packages("gghighlight")

p3 <- ggplot(df_paises, aes(x = date, y = esperanza_vida, group = country)) + 
        geom_point(color = "orange") + 
        geom_line(color = "orange") + 
        gghighlight::gghighlight(country == "Spain", use_group_by = FALSE)

p3


#- Pregunta 4) -----------------------------------------------------------------
#- muestra en un gráfico el país con más esperanza de vida cada año 
df_top_1 <- df %>% 
              group_by(date) %>% 
              top_n(1, esperanza_vida) %>% ungroup() %>% 
              arrange(date)
#- top_n() es una funcion  superseeded

#- pista: aes(x = date, y = esperanza_vida)
#- pista: tb has de usar geom_text()


p4 <- df_top_1 %>% 
  ggplot(aes(x = date, y = esperanza_vida)) + 
    geom_line(alpha = 0.3) +
    geom_text(aes(label = country), size = 2.25, nudge_y = 0.75) +
    geom_point() +
    scale_x_continuous(breaks = seq(1980, 2018, 5), limits = c(1980, 2018))

p4

#- hecho x estudiante:
df_top_1 %>% 
  ggplot(aes(date, esperanza_vida)) + 
  geom_line(aes(color = country)) +
  geom_point(aes(color = country)) + 
  geom_text(aes(label = country), size = 2.3)

#- con el paquete ggrepel
library(ggrepel)

p4 <- ggplot(df_top_1, aes(date, esperanza_vida)) + 
       geom_point(aes(color = country)) +
       geom_line() +
       ggrepel::geom_label_repel(aes(label = country) )

p4  #- no sale muy bien, xq hay muchas anotaciones 

#- Pregunta 5) -----------------------------------------------------------------
#- Con las observaciones de 2017, haz un boxplot para la Esperanza de vida agrupando por "region". Para que el gráfico se vea mejor haz un "coord_flip()" y añade las observaciones individuales, pero en lugar de con geom_point() hazlo con geom_jitter()

df_2017 <- df %>% filter(date == 2017)

p5 <- ggplot(df_2017, aes(x = region,  y = esperanza_vida)) + 
       geom_boxplot() + 
       coord_flip()  #- ya no es necesario (podríamos cambiar las v. de x e y)

p5

p5 + geom_jitter(width = 0.1, alpha = 1/4, color = "tomato")

p5 + geom_point(width = 0.1, alpha = 1/4, color = "tomato")


#- Pregunta 6) -----------------------------------------------------------------
#- Calcula la población total de cada región para el año 2017 y muéstrala en una gráfico de barras

df_pob <- df %>% filter(date == 2017) %>% 
                 group_by(region) %>% 
                 summarise(Pob_region = sum(poblacion, na.rm = TRUE)) %>% 
                 mutate(Pob_region = Pob_region /1000000)


p6 <- ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
        geom_col(fill = "steelblue") + coord_flip()

p6


#- ¿usar geom_col() o geom_bar()???? ----
#- https://r-charts.com/es/ranking/grafico-barras-ggplot2/

p6 <- ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
       geom_bar(fill = "steelblue")  + coord_flip()
p6  #- no funciona geom_bar() xq hay 2 v. dentro de aes's, solo se necesita la estetica x=, xq la  y se obtiene contando los casos !!!! su stat x defecto es count

p6 <- ggplot(df_pob,  aes(x = region)) + 
  geom_bar(fill = "steelblue")  + coord_flip()
p6   #- chuta pero ...  ¿xq sale todos en el valor 1? xq x defecto geom_bar() usa stat = "count" 


p6 <- ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
  geom_bar(fill = "steelblue", stat = "identity")  + coord_flip()  
p6  #- si pero ... #- ahora sí, si usas stat = "identity", solo q ahora hace falta y =
#- asi q si tenemos una tabla ya copn el nº de casos contados, entonces es mejor usar geom_col()

#- con geom_col() sale todo correcto (xq usa stat = "identity")
p6 <- ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
  geom_col(fill = "steelblue") + coord_flip()
p6

#- Pregunta 7) ------------------------------------------------------------------
#- haz que las barras del gráfico se ordenen de menor a mayor población
#- Pista: lo tenéis hacia el final de la sección 6.4 del tutorial sobre ggplot2. Lo que pasa es que en lugar de usar forcats::fct_infreq() debereis usar por ejemplo forcats::fct_reorder()

df_pob <- df_pob %>% 
  #- convertimos la v. region en factor con la f. as_factor()
   mutate(region.f = forcats::as_factor(region))

str(df_pob)     #- ahora
class(df_pob$region)    ; typeof(df_pob$region)
class(df_pob$region.f)  ; typeof(df_pob$region.f)   #- el factor
levels(df_pob$region.f)  #- los levels están ordenados alfabéticamente

#- AHORA reordenamos los niveles del factor en f. de Pob_region
df_pob <- df_pob %>% 
  mutate(region.ff = forcats::fct_reorder(region, Pob_region))
str(df_pob)
levels(df_pob$region.ff)  #- ahora los levels de region.ff estan ordenado por el valor de Pob_region (de menor a mayor)


p7 <- ggplot(df_pob,  aes(x = region.ff, y = Pob_region)) + 
  geom_col(fill = "steelblue") + 
  coord_flip()
p7

#- en realidad no hace falta coord_flip()
p7 <- ggplot(df_pob,  aes(y = region.ff, x = Pob_region)) + 
  geom_col(fill = "steelblue") 
p7

#- Pregunta 8) -----------------------------------------------------------------
#- Venga, un scatterplor entre x = PIB_percapita   e y = esperanza_vida Con los datos del año 2017 y que los puntos tengan un color diferente en función de la región. Añade geom_smooth() calculado para todas las observaciones de 2017

p <- ggplot(df_2017, aes(x = PIB_percapita, y = esperanza_vida)) + 
    geom_point(aes(color = region)) + 
    geom_smooth() 
p


#- Pregunta 9) -----------------------------------------------------------------
#- Intenta mejorar el último gráfico todo lo que puedas. Recuerda que puedes utilizar el asistente  ggThemeAssist.


p + theme(plot.subtitle = element_text(vjust = 1), 
          plot.caption  = element_text(vjust = 1), 
          panel.grid.major = element_line(colour = "white", linetype = "dashed"), 
          panel.background = element_rect(fill = "aliceblue"), 
          plot.background  = element_rect(fill = "aliceblue", linetype = "longdash")) +
          labs(title = "PIB percapita frente a esperanza de vida")

#- Pregunta 10) ----------------------------------------------------------------
#- Haz un mapa (una cooropleta) del mundo. Los colores de los países han de estar en función de los valores de la esperanza de vida en 2017 (divide los países en cuatro grupos o cuartiles)
#- yo os ayudo a buscar los datos de las geometrías de los países. Uso los siguientes paquetes
library("rnaturalearth")
library("rnaturalearthdata")
world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")
#- quito Antarctica y Groenlandia
world <- world %>% filter(subregion != "Antarctica") %>% filter(admin != "Greenland")
ggplot() + geom_sf(data = world) + theme_void()
world <- world %>% select(name, iso_a3, geometry) #- me quedo solo con las 2/3 variables que me hacen falta



no_quitar <- c("df", "world", "df_2017")
rm(list=ls()[! ls() %in% no_quitar])

#- primero has de unir las tablas "df" y "world". la variable de unión es by = c("iso3c" = "iso_a3")

df_world <- left_join(df_2017, world, by = c("iso3c" = "iso_a3") ) 

#- una vez hemos unido las tablas solo hay que graficarlo con geom_sf(), pero antes has de discretizar la variable Esperanza de vida en 4 grupos. ¿te acuerdas de la funcion ntile()

df_world <- df_world %>% mutate(esperanza_vida_4 = ntile(esperanza_vida, 4))   #- como integer

df_world <- df_world %>% mutate(esperanza_vida_4.f = as_factor(ntile(esperanza_vida, 4))) #- como factor

#- fijate q la v. "esperanza_vida" es númerica (x tanto continua)
#- fijate q la v. "esperanza_vida_4" es integer 
#- fijate q la v. "esperanza_vida_4.f" es factor

str(df_world)


#- para hacer el mapa tendrás que usar geom_sf()  y tendrás que usar las esteticas geometry y fill. Recuerda que las estéticas siempre van dentro de aes()
p10 <- ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4)) 
p10
p10 <- ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) 
p10

#- podemos jugar con las escalas
p10 + scale_fill_viridis_d()
p10 +  scale_fill_brewer()
p10 + scale_fill_brewer(palette = "Greens")

my_escala <- c('gray90','steelblue1','steelblue4', "pink")
p10 + scale_fill_manual(values = my_escala, name = "Esperanza de vida", labels = c("poquisima E", "poca E", "bastante E", "mucha E"))

#- quitamos los NA's??
df_world.2 <- df_world %>% 
  filter(!is.na(esperanza_vida))
p10 <- ggplot(df_world.2) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) 
p10


#- ¿que pasa aquí con la escala?
ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) + scale_fill_viridis_c()



#- Pregunta 11) ----------------------------------------------------------------
#- Haz el mismo mapa pero un small multiple para los años 2000, 2005, 2010 y 2017

df_small <- df %>% filter(date %in% c(2000, 2005, 2010, 2017))
df_world_small <- left_join(df_small, world, by = c("iso3c" = "iso_a3") ) 

df_world_small <- df_world_small %>% 
            group_by(date) %>% 
            mutate(esperanza_vida_4 = ntile(esperanza_vida, 4)) %>% ungroup() %>% 
            mutate(esperanza_vida_4.f = forcats::as_factor(esperanza_vida_4))

p11 <- ggplot(df_world_small) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) + 
  scale_fill_viridis_d() +
  facet_wrap(vars(date))

p11

#- BONUS: gracias Karamanis!!  --------------------------------
#- https://github.com/gkaramanis/tidytuesday/tree/master/2021/2021-week44

library(sf)
lat <- 30   #- 40.76175 #- 30
lon <- 58 #- -1.028781  #- 58
ortho <- paste0('+proj=ortho +lat_0=', lat, ' +lon_0=', lon,
                ' +x_0=0 +y_0=0 +a=6371000 +b=6371000 +units=m +no_defs')

circle <- st_point(x = c(0, 0)) %>%
  st_buffer(dist = 6371000) %>%
  st_sfc(crs = ortho) %>%
  st_transform(crs = 4326)


df_world <- st_as_sf(df_world)


world_ortho <- st_cast(df_world, "MULTIPOLYGON") %>%
  st_cast("POLYGON", do_split = TRUE) %>%
  st_transform(crs = ortho)


p10a <- ggplot(world_ortho) + 
  geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) + 
  scale_fill_brewer(palette = "Greens") + theme_void() 

p10a

p10b <- ggplot(world_ortho) + 
  geom_sf(data = circle, fill = "cornflowerblue", color = NA, size = 2) +
  geom_sf(aes(geometry = geometry, fill = esperanza_vida_4.f)) + 
  scale_fill_brewer(palette = "Greens") + 
  theme_void() +
  theme(legend.position = "bottom") 

p10b

p10b + 
  guides(fill = guide_colorbar(title = "Life Expectancy (Years)", title.position = "top", title.hjust = 0.5)) +
labs(
  caption = "Data: spData package · Graphic: Georgios Karamanis"
) +
  guides(fill = guide_colorbar(title = "Life Expectancy (Years)", title.position = "top", title.hjust = 0.5)) +
  theme_void(base_size = 15) +
  theme(
    legend.position = "top",
    legend.title = element_text(color = "grey99", size = 22),
    legend.text = element_text(color = "grey97"),
    legend.key.height = unit(0.5, "line"),
    legend.key.width = unit(3, "line"),
    plot.background = element_rect(fill = "#200034", color = NA),
    plot.caption = element_text(color = "grey97"),
    plot.margin = margin(20, 20, 20, 20)
  )
